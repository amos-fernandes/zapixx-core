#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

class PerformanceOptimizer {
  constructor() {
    this.optimizations = [];
    this.metrics = {};
  }

  log(message, type = 'info') {
    const timestamp = new Date().toISOString();
    const prefix = type === 'error' ? '🔴' : type === 'warning' ? '🟡' : type === 'success' ? '🟢' : 'ℹ️';
    console.log(`${prefix} [${timestamp}] ${message}`);
  }

  addOptimization(category, description, impact, effort) {
    this.optimizations.push({
      category,
      description,
      impact, // HIGH, MEDIUM, LOW
      effort, // HIGH, MEDIUM, LOW
      timestamp: new Date().toISOString()
    });
  }

  analyzeBackendStructure() {
    this.log('Analisando estrutura do backend...');
    
    const backendPath = '/home/ubuntu/pix2usdt-gateway/backend';
    
    // Verificar se há middleware de cache
    const serverFile = path.join(backendPath, 'server.js');
    if (fs.existsSync(serverFile)) {
      const content = fs.readFileSync(serverFile, 'utf8');
      
      if (!content.includes('redis') && !content.includes('cache')) {
        this.addOptimization(
          'Caching',
          'Implementar cache Redis para cotações e dados frequentes',
          'HIGH',
          'MEDIUM'
        );
      }
      
      if (!content.includes('compression')) {
        this.addOptimization(
          'Compression',
          'Implementar compressão gzip para responses',
          'MEDIUM',
          'LOW'
        );
      }
    }

    // Verificar estrutura de modelos
    const modelsPath = path.join(backendPath, 'src/models');
    if (fs.existsSync(modelsPath)) {
      const modelFiles = fs.readdirSync(modelsPath);
      
      modelFiles.forEach(file => {
        const filePath = path.join(modelsPath, file);
        const content = fs.readFileSync(filePath, 'utf8');
        
        // Verificar se há queries N+1
        if (content.includes('findById') && content.includes('forEach')) {
          this.addOptimization(
            'Database',
            `Possível problema N+1 em ${file} - considere usar joins`,
            'HIGH',
            'MEDIUM'
          );
        }
        
        // Verificar índices
        if (content.includes('WHERE') && !content.includes('INDEX')) {
          this.addOptimization(
            'Database',
            `Adicionar índices para queries em ${file}`,
            'MEDIUM',
            'LOW'
          );
        }
      });
    }

    this.log('Análise da estrutura do backend concluída');
  }

  analyzeFrontendPerformance() {
    this.log('Analisando performance do frontend...');
    
    const frontendPath = '/home/ubuntu/pix2usdt-gateway/frontend/pix2usdt-frontend';
    
    // Verificar package.json para dependências pesadas
    const packageFile = path.join(frontendPath, 'package.json');
    if (fs.existsSync(packageFile)) {
      const packageContent = JSON.parse(fs.readFileSync(packageFile, 'utf8'));
      const dependencies = packageContent.dependencies || {};
      
      // Verificar dependências conhecidas por serem pesadas
      const heavyDeps = ['moment', 'lodash', 'jquery'];
      heavyDeps.forEach(dep => {
        if (dependencies[dep]) {
          this.addOptimization(
            'Bundle Size',
            `Considere substituir ${dep} por alternativa mais leve`,
            'MEDIUM',
            'MEDIUM'
          );
        }
      });
    }

    // Verificar se há lazy loading
    const srcPath = path.join(frontendPath, 'src');
    if (fs.existsSync(srcPath)) {
      const appFile = path.join(srcPath, 'App.jsx');
      if (fs.existsSync(appFile)) {
        const content = fs.readFileSync(appFile, 'utf8');
        
        if (!content.includes('lazy') && !content.includes('Suspense')) {
          this.addOptimization(
            'Code Splitting',
            'Implementar lazy loading para componentes de rota',
            'MEDIUM',
            'LOW'
          );
        }
      }
    }

    this.log('Análise de performance do frontend concluída');
  }

  analyzeAPIPerformance() {
    this.log('Analisando performance da API...');
    
    const routesPath = '/home/ubuntu/pix2usdt-gateway/backend/src/routes';
    
    if (fs.existsSync(routesPath)) {
      const routeFiles = fs.readdirSync(routesPath);
      
      routeFiles.forEach(file => {
        const filePath = path.join(routesPath, file);
        const content = fs.readFileSync(filePath, 'utf8');
        
        // Verificar paginação
        if (content.includes('findAll') && !content.includes('limit')) {
          this.addOptimization(
            'API Performance',
            `Implementar paginação em ${file}`,
            'HIGH',
            'LOW'
          );
        }
        
        // Verificar rate limiting específico
        if (content.includes('POST') && !content.includes('rateLimit')) {
          this.addOptimization(
            'API Security',
            `Implementar rate limiting específico para endpoints POST em ${file}`,
            'MEDIUM',
            'LOW'
          );
        }
      });
    }

    this.log('Análise de performance da API concluída');
  }

  analyzeDatabasePerformance() {
    this.log('Analisando performance do banco de dados...');
    
    // Verificar configuração de pool de conexões
    const dbConfigFile = '/home/ubuntu/pix2usdt-gateway/backend/src/config/database.js';
    if (fs.existsSync(dbConfigFile)) {
      const content = fs.readFileSync(dbConfigFile, 'utf8');
      
      if (!content.includes('pool')) {
        this.addOptimization(
          'Database',
          'Implementar pool de conexões para melhor performance',
          'HIGH',
          'MEDIUM'
        );
      }
      
      if (!content.includes('timeout')) {
        this.addOptimization(
          'Database',
          'Configurar timeouts apropriados para queries',
          'MEDIUM',
          'LOW'
        );
      }
    }

    // Sugerir otimizações específicas para transações financeiras
    this.addOptimization(
      'Database',
      'Implementar índices compostos para queries de transações por usuário e data',
      'HIGH',
      'LOW'
    );

    this.addOptimization(
      'Database',
      'Considere particionamento de tabela de transações por data',
      'MEDIUM',
      'HIGH'
    );

    this.log('Análise de performance do banco de dados concluída');
  }

  analyzeSecurityPerformance() {
    this.log('Analisando impacto de segurança na performance...');
    
    // Verificar se há muitas validações síncronas
    const validationFile = '/home/ubuntu/pix2usdt-gateway/backend/src/middleware/validation.js';
    if (fs.existsSync(validationFile)) {
      const content = fs.readFileSync(validationFile, 'utf8');
      
      if (content.includes('bcrypt.compare') && !content.includes('async')) {
        this.addOptimization(
          'Security Performance',
          'Otimizar validações de senha para serem assíncronas',
          'MEDIUM',
          'LOW'
        );
      }
    }

    this.addOptimization(
      'Security Performance',
      'Implementar cache para resultados de KYC para evitar revalidações',
      'MEDIUM',
      'MEDIUM'
    );

    this.log('Análise de impacto de segurança na performance concluída');
  }

  generatePerformanceMetrics() {
    this.log('Gerando métricas de performance...');
    
    // Simular métricas baseadas na estrutura atual
    this.metrics = {
      estimatedResponseTime: {
        auth: '200ms',
        transactions: '500ms',
        rate: '100ms'
      },
      estimatedThroughput: {
        concurrent_users: 100,
        requests_per_second: 50
      },
      bottlenecks: [
        'Database queries sem índices',
        'Falta de cache para cotações',
        'Validações síncronas'
      ],
      recommendations: {
        immediate: 'Implementar cache Redis',
        short_term: 'Otimizar queries do banco',
        long_term: 'Implementar microserviços'
      }
    };

    this.log('Métricas de performance geradas');
  }

  generateOptimizationPlan() {
    this.log('Gerando plano de otimização...');
    
    // Ordenar otimizações por impacto e esforço
    const prioritized = this.optimizations.sort((a, b) => {
      const impactWeight = { HIGH: 3, MEDIUM: 2, LOW: 1 };
      const effortWeight = { LOW: 3, MEDIUM: 2, HIGH: 1 };
      
      const scoreA = impactWeight[a.impact] + effortWeight[a.effort];
      const scoreB = impactWeight[b.impact] + effortWeight[b.effort];
      
      return scoreB - scoreA;
    });

    return {
      immediate: prioritized.filter(opt => 
        opt.impact === 'HIGH' && opt.effort === 'LOW'
      ),
      shortTerm: prioritized.filter(opt => 
        opt.impact === 'HIGH' && opt.effort === 'MEDIUM'
      ),
      longTerm: prioritized.filter(opt => 
        opt.impact === 'MEDIUM' || opt.effort === 'HIGH'
      )
    };
  }

  runFullAnalysis() {
    this.log('=== Iniciando Análise de Performance PIX2USDT Gateway ===');
    
    this.analyzeBackendStructure();
    this.analyzeFrontendPerformance();
    this.analyzeAPIPerformance();
    this.analyzeDatabasePerformance();
    this.analyzeSecurityPerformance();
    this.generatePerformanceMetrics();
    
    const plan = this.generateOptimizationPlan();
    this.generateReport(plan);
  }

  generateReport(plan) {
    this.log('=== Relatório de Performance e Otimização ===');
    
    this.log(`\n📊 Métricas Estimadas:`);
    this.log(`   ⏱️  Tempo de resposta médio:`);
    this.log(`      - Autenticação: ${this.metrics.estimatedResponseTime.auth}`);
    this.log(`      - Transações: ${this.metrics.estimatedResponseTime.transactions}`);
    this.log(`      - Cotações: ${this.metrics.estimatedResponseTime.rate}`);
    
    this.log(`   🚀 Capacidade estimada:`);
    this.log(`      - Usuários simultâneos: ${this.metrics.estimatedThroughput.concurrent_users}`);
    this.log(`      - Requests/segundo: ${this.metrics.estimatedThroughput.requests_per_second}`);
    
    this.log(`\n🔍 Principais Gargalos Identificados:`);
    this.metrics.bottlenecks.forEach((bottleneck, index) => {
      this.log(`   ${index + 1}. ${bottleneck}`);
    });
    
    this.log(`\n🎯 Plano de Otimização:`);
    
    if (plan.immediate.length > 0) {
      this.log(`\n🚨 Ações Imediatas (Alto Impacto, Baixo Esforço):`);
      plan.immediate.forEach((opt, index) => {
        this.log(`   ${index + 1}. ${opt.description}`);
      });
    }
    
    if (plan.shortTerm.length > 0) {
      this.log(`\n📅 Curto Prazo (Alto Impacto, Médio Esforço):`);
      plan.shortTerm.forEach((opt, index) => {
        this.log(`   ${index + 1}. ${opt.description}`);
      });
    }
    
    if (plan.longTerm.length > 0) {
      this.log(`\n🔮 Longo Prazo:`);
      plan.longTerm.forEach((opt, index) => {
        this.log(`   ${index + 1}. ${opt.description}`);
      });
    }
    
    // Score de performance
    const totalOptimizations = this.optimizations.length;
    const highImpactOpts = this.optimizations.filter(opt => opt.impact === 'HIGH').length;
    const performanceScore = Math.max(0, Math.round(((20 - highImpactOpts) / 20) * 100));
    
    this.log(`\n⚡ Score de Performance: ${performanceScore}/100`);
    
    if (performanceScore >= 80) {
      this.log('✅ Performance: EXCELENTE', 'success');
    } else if (performanceScore >= 60) {
      this.log('⚠️  Performance: BOA - Algumas otimizações recomendadas', 'warning');
    } else {
      this.log('🔴 Performance: PRECISA MELHORAR - Otimizações necessárias', 'error');
    }
    
    this.log(`\n💡 Próximos Passos Recomendados:`);
    this.log(`   1. ${this.metrics.recommendations.immediate}`);
    this.log(`   2. ${this.metrics.recommendations.short_term}`);
    this.log(`   3. ${this.metrics.recommendations.long_term}`);
  }
}

// Executar análise se chamado diretamente
if (require.main === module) {
  const optimizer = new PerformanceOptimizer();
  optimizer.runFullAnalysis();
}

module.exports = PerformanceOptimizer;
