const User = require('../models/User');
const { generateToken, generateRefreshToken } = require('../middleware/auth');
const emailService = require('../services/emailService');

class AuthController {
  static async register(req, res) {
    try {
      const { email, password, firstName, lastName, phone, pixKey } = req.body;

      // Verificar se o usuário já existe
      const existingUser = await User.findByEmail(email);
      if (existingUser) {
        return res.status(409).json({ 
          message: 'E-mail já cadastrado' 
        });
      }

      // Criar novo usuário
      const result = await User.create({
        email,
        password,
        firstName,
        lastName,
        phone,
        pixKey
      });

      // Enviar e-mail de verificação
      try {
        await emailService.sendVerificationEmail(email, result.emailVerificationToken);
      } catch (emailError) {
        console.error('Erro ao enviar e-mail de verificação:', emailError);
        // Não falhar o registro se o e-mail não puder ser enviado
      }

      res.status(201).json({
        message: 'Usuário criado com sucesso. Verifique seu e-mail para ativar a conta.',
        user: {
          id: result.user.id,
          email: result.user.email,
          firstName: result.user.first_name,
          lastName: result.user.last_name,
          emailVerified: result.user.email_verified
        }
      });

    } catch (error) {
      console.error('Erro no registro:', error);
      
      if (error.code === '23505') { // Violação de constraint unique
        return res.status(409).json({ 
          message: 'E-mail já cadastrado' 
        });
      }

      res.status(500).json({ 
        message: 'Erro interno do servidor' 
      });
    }
  }

  static async login(req, res) {
    try {
      const { email, password } = req.body;

      // Buscar usuário
      const user = await User.findByEmail(email);
      if (!user) {
        return res.status(401).json({ 
          message: 'Credenciais inválidas' 
        });
      }

      // Verificar senha
      const isValidPassword = await User.verifyPassword(password, user.password_hash);
      if (!isValidPassword) {
        return res.status(401).json({ 
          message: 'Credenciais inválidas' 
        });
      }

      // Verificar se a conta está ativa
      if (!user.is_active) {
        return res.status(403).json({ 
          message: 'Conta desativada. Entre em contato com o suporte.' 
        });
      }

      // Gerar tokens
      const token = generateToken(user.id);
      const refreshToken = generateRefreshToken(user.id);

      res.json({
        message: 'Login realizado com sucesso',
        token,
        refreshToken,
        user: {
          id: user.id,
          email: user.email,
          firstName: user.first_name,
          lastName: user.last_name,
          kycStatus: user.kyc_status,
          emailVerified: user.email_verified,
          twoFactorEnabled: user.two_factor_enabled
        }
      });

    } catch (error) {
      console.error('Erro no login:', error);
      res.status(500).json({ 
        message: 'Erro interno do servidor' 
      });
    }
  }

  static async verifyEmail(req, res) {
    try {
      const { token } = req.params;

      const result = await User.verifyEmail(token);
      if (!result) {
        return res.status(400).json({ 
          message: 'Token de verificação inválido ou expirado' 
        });
      }

      res.json({
        message: 'E-mail verificado com sucesso',
        user: {
          id: result.id,
          email: result.email,
          emailVerified: result.email_verified
        }
      });

    } catch (error) {
      console.error('Erro na verificação de e-mail:', error);
      res.status(500).json({ 
        message: 'Erro interno do servidor' 
      });
    }
  }

  static async resendVerificationEmail(req, res) {
    try {
      const { email } = req.body;

      const user = await User.findByEmail(email);
      if (!user) {
        return res.status(404).json({ 
          message: 'Usuário não encontrado' 
        });
      }

      if (user.email_verified) {
        return res.status(400).json({ 
          message: 'E-mail já verificado' 
        });
      }

      // Gerar novo token de verificação
      const { v4: uuidv4 } = require('uuid');
      const newToken = uuidv4();
      
      // Atualizar token no banco (implementar método no modelo User)
      // await User.updateVerificationToken(user.id, newToken);

      // Enviar e-mail
      await emailService.sendVerificationEmail(email, newToken);

      res.json({
        message: 'E-mail de verificação reenviado com sucesso'
      });

    } catch (error) {
      console.error('Erro ao reenviar e-mail de verificação:', error);
      res.status(500).json({ 
        message: 'Erro interno do servidor' 
      });
    }
  }

  static async refreshToken(req, res) {
    try {
      const { refreshToken } = req.body;

      if (!refreshToken) {
        return res.status(401).json({ 
          message: 'Refresh token requerido' 
        });
      }

      const jwt = require('jsonwebtoken');
      const decoded = jwt.verify(refreshToken, process.env.JWT_SECRET);

      if (decoded.type !== 'refresh') {
        return res.status(401).json({ 
          message: 'Token inválido' 
        });
      }

      // Verificar se o usuário ainda existe
      const user = await User.findById(decoded.userId);
      if (!user || !user.is_active) {
        return res.status(401).json({ 
          message: 'Usuário não encontrado ou inativo' 
        });
      }

      // Gerar novos tokens
      const newToken = generateToken(user.id);
      const newRefreshToken = generateRefreshToken(user.id);

      res.json({
        token: newToken,
        refreshToken: newRefreshToken
      });

    } catch (error) {
      console.error('Erro no refresh token:', error);
      
      if (error.name === 'TokenExpiredError' || error.name === 'JsonWebTokenError') {
        return res.status(401).json({ 
          message: 'Refresh token inválido ou expirado' 
        });
      }

      res.status(500).json({ 
        message: 'Erro interno do servidor' 
      });
    }
  }

  static async logout(req, res) {
    // Em uma implementação mais robusta, você poderia invalidar o token
    // adicionando-o a uma blacklist no Redis ou banco de dados
    res.json({
      message: 'Logout realizado com sucesso'
    });
  }
}

module.exports = AuthController;
