const Transaction = require('../models/Transaction');
const Wallet = require('../models/Wallet');
const exchangeService = require('../services/exchangeService');
const pixService = require('../services/pixService');
const { v4: uuidv4 } = require('uuid');

class TransactionController {
  static async createTransaction(req, res) {
    try {
      const { pixAmount, destinationWalletId, destinationAddress, destinationNetwork } = req.body;
      const userId = req.user.id;

      // Validar se o usuário tem KYC aprovado
      if (req.user.kycStatus !== 'approved') {
        return res.status(403).json({
          message: 'KYC não aprovado. Complete a verificação de identidade primeiro.',
          code: 'KYC_NOT_APPROVED'
        });
      }

      // Obter cotação atual do USDT
      const exchangeRate = await exchangeService.getUSDTRate();
      if (!exchangeRate) {
        return res.status(503).json({
          message: 'Serviço de cotação temporariamente indisponível'
        });
      }

      // Calcular valores
      const platformFeeRate = 0.015; // 1.5%
      const platformFee = pixAmount * platformFeeRate;
      const netAmount = pixAmount - platformFee;
      const usdtAmount = netAmount / exchangeRate.rate;

      // Validar carteira de destino se fornecida
      let validatedWallet = null;
      if (destinationWalletId) {
        validatedWallet = await Wallet.findById(destinationWalletId);
        if (!validatedWallet || validatedWallet.user_id !== userId) {
          return res.status(400).json({
            message: 'Carteira de destino inválida'
          });
        }
      }

      // Gerar dados do PIX
      const pixData = await pixService.generatePixPayment({
        amount: pixAmount,
        description: `Compra de USDT - ${usdtAmount.toFixed(8)} USDT`,
        userId: userId
      });

      // Criar transação
      const transactionData = {
        userId,
        pixAmount,
        usdtAmount,
        usdtRate: exchangeRate.rate,
        pixKey: pixData.pixKey,
        pixQrCode: pixData.qrCode,
        destinationWalletId: validatedWallet?.id || null,
        destinationAddress: destinationAddress || validatedWallet?.wallet_address || null,
        destinationNetwork: destinationNetwork || validatedWallet?.network || null,
        platformFee,
        exchangeFee: 0, // Será calculada na execução
        networkFee: 0, // Será calculada na execução
        metadata: {
          exchangeRateSource: exchangeRate.source,
          pixPaymentId: pixData.paymentId
        }
      };

      const transaction = await Transaction.create(transactionData);

      res.status(201).json({
        message: 'Transação criada com sucesso',
        transaction: {
          id: transaction.id,
          status: transaction.status,
          pixAmount: transaction.pix_amount,
          usdtAmount: transaction.usdt_amount,
          usdtRate: transaction.usdt_rate,
          platformFee: transaction.platform_fee,
          pixQrCode: transaction.pix_qr_code,
          pixKey: transaction.pix_key,
          destinationAddress: transaction.destination_address,
          destinationNetwork: transaction.destination_network,
          createdAt: transaction.created_at
        },
        paymentInfo: {
          qrCode: pixData.qrCode,
          pixKey: pixData.pixKey,
          amount: pixAmount,
          expiresAt: pixData.expiresAt
        }
      });

    } catch (error) {
      console.error('Erro ao criar transação:', error);
      res.status(500).json({
        message: 'Erro interno do servidor'
      });
    }
  }

  static async getTransactions(req, res) {
    try {
      const userId = req.user.id;
      const page = parseInt(req.query.page) || 1;
      const limit = parseInt(req.query.limit) || 20;
      const offset = (page - 1) * limit;

      const transactions = await Transaction.findByUserId(userId, limit, offset);

      const formattedTransactions = transactions.map(tx => ({
        id: tx.id,
        status: tx.status,
        pixAmount: tx.pix_amount,
        usdtAmount: tx.usdt_amount,
        usdtRate: tx.usdt_rate,
        platformFee: tx.platform_fee,
        destinationAddress: tx.destination_address,
        destinationNetwork: tx.destination_network,
        createdAt: tx.created_at,
        updatedAt: tx.updated_at,
        pixConfirmedAt: tx.pix_confirmed_at,
        blockchainTxHash: tx.blockchain_tx_hash
      }));

      res.json({
        transactions: formattedTransactions,
        pagination: {
          page,
          limit,
          hasMore: transactions.length === limit
        }
      });

    } catch (error) {
      console.error('Erro ao buscar transações:', error);
      res.status(500).json({
        message: 'Erro interno do servidor'
      });
    }
  }

  static async getTransaction(req, res) {
    try {
      const { id } = req.params;
      const userId = req.user.id;

      const transaction = await Transaction.findById(id);
      if (!transaction) {
        return res.status(404).json({
          message: 'Transação não encontrada'
        });
      }

      // Verificar se a transação pertence ao usuário
      if (transaction.user_id !== userId) {
        return res.status(403).json({
          message: 'Acesso negado'
        });
      }

      res.json({
        transaction: {
          id: transaction.id,
          status: transaction.status,
          pixAmount: transaction.pix_amount,
          usdtAmount: transaction.usdt_amount,
          usdtRate: transaction.usdt_rate,
          platformFee: transaction.platform_fee,
          exchangeFee: transaction.exchange_fee,
          networkFee: transaction.network_fee,
          pixKey: transaction.pix_key,
          pixQrCode: transaction.pix_qr_code,
          pixTransactionId: transaction.pix_transaction_id,
          pixConfirmedAt: transaction.pix_confirmed_at,
          destinationAddress: transaction.destination_address,
          destinationNetwork: transaction.destination_network,
          blockchainTxHash: transaction.blockchain_tx_hash,
          exchangeOrderId: transaction.exchange_order_id,
          errorMessage: transaction.error_message,
          metadata: transaction.metadata,
          createdAt: transaction.created_at,
          updatedAt: transaction.updated_at
        }
      });

    } catch (error) {
      console.error('Erro ao buscar transação:', error);
      res.status(500).json({
        message: 'Erro interno do servidor'
      });
    }
  }

  static async getCurrentRate(req, res) {
    try {
      const { amount } = req.query;
      const pixAmount = parseFloat(amount) || 100; // Valor padrão R$ 100

      const exchangeRate = await exchangeService.getUSDTRate();
      if (!exchangeRate) {
        return res.status(503).json({
          message: 'Serviço de cotação temporariamente indisponível'
        });
      }

      // Calcular valores
      const platformFeeRate = 0.015; // 1.5%
      const platformFee = pixAmount * platformFeeRate;
      const netAmount = pixAmount - platformFee;
      const usdtAmount = netAmount / exchangeRate.rate;

      res.json({
        pixAmount,
        usdtAmount: parseFloat(usdtAmount.toFixed(8)),
        rate: exchangeRate.rate,
        platformFee: parseFloat(platformFee.toFixed(2)),
        platformFeeRate,
        netAmount: parseFloat(netAmount.toFixed(2)),
        source: exchangeRate.source,
        timestamp: exchangeRate.timestamp
      });

    } catch (error) {
      console.error('Erro ao obter cotação:', error);
      res.status(500).json({
        message: 'Erro interno do servidor'
      });
    }
  }

  static async getTransactionStats(req, res) {
    try {
      const userId = req.user.id;
      const { startDate, endDate } = req.query;

      const start = startDate ? new Date(startDate) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000); // 30 dias atrás
      const end = endDate ? new Date(endDate) : new Date();

      const stats = await Transaction.getTransactionStats(userId, start, end);

      res.json({
        stats: {
          totalTransactions: parseInt(stats.total_transactions),
          completedTransactions: parseInt(stats.completed_transactions),
          failedTransactions: parseInt(stats.failed_transactions),
          totalPixAmount: parseFloat(stats.total_pix_amount || 0),
          totalUsdtAmount: parseFloat(stats.total_usdt_amount || 0),
          averageRate: parseFloat(stats.avg_rate || 0),
          successRate: stats.total_transactions > 0 
            ? (stats.completed_transactions / stats.total_transactions * 100).toFixed(2)
            : 0
        },
        period: {
          startDate: start.toISOString(),
          endDate: end.toISOString()
        }
      });

    } catch (error) {
      console.error('Erro ao obter estatísticas:', error);
      res.status(500).json({
        message: 'Erro interno do servidor'
      });
    }
  }
}

module.exports = TransactionController;
