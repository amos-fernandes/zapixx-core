const User = require('../models/User');
const Wallet = require('../models/Wallet');
const emailService = require('../services/emailService');

class UserController {
  static async getProfile(req, res) {
    try {
      const userId = req.user.id;
      const user = await User.findById(userId);
      
      if (!user) {
        return res.status(404).json({ 
          message: 'Usuário não encontrado' 
        });
      }

      res.json({
        user: {
          id: user.id,
          email: user.email,
          firstName: user.first_name,
          lastName: user.last_name,
          phone: user.phone,
          pixKey: user.pix_key,
          kycStatus: user.kyc_status,
          emailVerified: user.email_verified,
          twoFactorEnabled: user.two_factor_enabled,
          createdAt: user.created_at,
          updatedAt: user.updated_at
        }
      });

    } catch (error) {
      console.error('Erro ao obter perfil:', error);
      res.status(500).json({ 
        message: 'Erro interno do servidor' 
      });
    }
  }

  static async updatePixKey(req, res) {
    try {
      const userId = req.user.id;
      const { pixKey } = req.body;

      const result = await User.updatePixKey(userId, pixKey);
      
      res.json({
        message: 'Chave PIX atualizada com sucesso',
        pixKey: result.pix_key
      });

    } catch (error) {
      console.error('Erro ao atualizar chave PIX:', error);
      res.status(500).json({ 
        message: 'Erro interno do servidor' 
      });
    }
  }

  static async addWallet(req, res) {
    try {
      const userId = req.user.id;
      const { walletAddress, network, label } = req.body;

      // Verificar se a carteira já existe
      const existingWallet = await Wallet.findByAddressAndNetwork(walletAddress, network);
      if (existingWallet) {
        return res.status(409).json({ 
          message: 'Esta carteira já está cadastrada' 
        });
      }

      // Criar nova carteira
      const result = await Wallet.create({
        userId,
        walletAddress,
        network,
        label
      });

      // Enviar e-mail de verificação
      try {
        const user = await User.findById(userId);
        await emailService.sendWalletVerificationEmail(
          user.email, 
          result.verificationToken,
          walletAddress,
          network
        );
      } catch (emailError) {
        console.error('Erro ao enviar e-mail de verificação de carteira:', emailError);
      }

      res.status(201).json({
        message: 'Carteira adicionada com sucesso. Verifique seu e-mail para confirmar.',
        wallet: {
          id: result.wallet.id,
          walletAddress: result.wallet.wallet_address,
          network: result.wallet.network,
          label: result.wallet.label,
          isVerified: result.wallet.is_verified,
          createdAt: result.wallet.created_at
        }
      });

    } catch (error) {
      console.error('Erro ao adicionar carteira:', error);
      res.status(500).json({ 
        message: 'Erro interno do servidor' 
      });
    }
  }

  static async getWallets(req, res) {
    try {
      const userId = req.user.id;
      const wallets = await Wallet.findByUserId(userId);

      res.json({
        wallets: wallets.map(wallet => ({
          id: wallet.id,
          walletAddress: wallet.wallet_address,
          network: wallet.network,
          label: wallet.label,
          isVerified: wallet.is_verified,
          createdAt: wallet.created_at
        }))
      });

    } catch (error) {
      console.error('Erro ao obter carteiras:', error);
      res.status(500).json({ 
        message: 'Erro interno do servidor' 
      });
    }
  }

  static async verifyWallet(req, res) {
    try {
      const { token } = req.params;

      const result = await Wallet.verifyWallet(token);
      if (!result) {
        return res.status(400).json({ 
          message: 'Token de verificação inválido ou expirado' 
        });
      }

      res.json({
        message: 'Carteira verificada com sucesso',
        wallet: {
          id: result.id,
          walletAddress: result.wallet_address,
          network: result.network,
          isVerified: result.is_verified
        }
      });

    } catch (error) {
      console.error('Erro na verificação de carteira:', error);
      res.status(500).json({ 
        message: 'Erro interno do servidor' 
      });
    }
  }

  static async removeWallet(req, res) {
    try {
      const userId = req.user.id;
      const { id } = req.params;

      const result = await Wallet.deactivate(id, userId);
      if (!result) {
        return res.status(404).json({ 
          message: 'Carteira não encontrada' 
        });
      }

      res.json({
        message: 'Carteira removida com sucesso'
      });

    } catch (error) {
      console.error('Erro ao remover carteira:', error);
      res.status(500).json({ 
        message: 'Erro interno do servidor' 
      });
    }
  }

  static async updateWalletLabel(req, res) {
    try {
      const userId = req.user.id;
      const { id } = req.params;
      const { label } = req.body;

      const result = await Wallet.updateLabel(id, userId, label);
      if (!result) {
        return res.status(404).json({ 
          message: 'Carteira não encontrada' 
        });
      }

      res.json({
        message: 'Rótulo da carteira atualizado com sucesso',
        label: result.label
      });

    } catch (error) {
      console.error('Erro ao atualizar rótulo da carteira:', error);
      res.status(500).json({ 
        message: 'Erro interno do servidor' 
      });
    }
  }

  static async enable2FA(req, res) {
    try {
      const userId = req.user.id;
      
      // Em uma implementação completa, você geraria um secret TOTP aqui
      // e retornaria um QR code para o usuário escanear
      const secret = 'mock-2fa-secret'; // Implementar com biblioteca como 'speakeasy'

      await User.enable2FA(userId, secret);

      res.json({
        message: '2FA habilitado com sucesso',
        // qrCode: qrCodeUrl, // URL do QR code para configurar no app
        // backupCodes: backupCodes // Códigos de backup
      });

    } catch (error) {
      console.error('Erro ao habilitar 2FA:', error);
      res.status(500).json({ 
        message: 'Erro interno do servidor' 
      });
    }
  }

  static async disable2FA(req, res) {
    try {
      const userId = req.user.id;
      
      await User.disable2FA(userId);

      res.json({
        message: '2FA desabilitado com sucesso'
      });

    } catch (error) {
      console.error('Erro ao desabilitar 2FA:', error);
      res.status(500).json({ 
        message: 'Erro interno do servidor' 
      });
    }
  }
}

module.exports = UserController;
