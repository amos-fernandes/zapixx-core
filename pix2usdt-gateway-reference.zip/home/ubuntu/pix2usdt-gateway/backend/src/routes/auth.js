const express = require('express');
const router = express.Router();
const AuthController = require('../controllers/authController');
const { 
  validateUserRegistration, 
  validateLogin,
  validateUuidParam 
} = require('../middleware/validation');

// Registro de usuário
router.post('/register', validateUserRegistration, AuthController.register);

// Login
router.post('/login', validateLogin, AuthController.login);

// Verificação de e-mail
router.get('/verify-email/:token', validateUuidParam('token'), AuthController.verifyEmail);

// Reenviar e-mail de verificação
router.post('/resend-verification', AuthController.resendVerificationEmail);

// Refresh token
router.post('/refresh-token', AuthController.refreshToken);

// Logout
router.post('/logout', AuthController.logout);

module.exports = router;
