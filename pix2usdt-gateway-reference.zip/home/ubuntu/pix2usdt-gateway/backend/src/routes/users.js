const express = require('express');
const router = express.Router();
const UserController = require('../controllers/userController');
const { 
  authenticateToken, 
  requireEmailVerification 
} = require('../middleware/auth');
const { 
  validatePixKeyUpdate,
  validateWalletCreation,
  validateWalletAddressMiddleware,
  validateUuidParam 
} = require('../middleware/validation');

// Middleware de autenticação para todas as rotas
router.use(authenticateToken);

// Obter perfil do usuário
router.get('/profile', UserController.getProfile);

// Atualizar chave PIX (requer e-mail verificado)
router.put('/pix-key', 
  requireEmailVerification,
  validatePixKeyUpdate, 
  UserController.updatePixKey
);

// Gerenciamento de carteiras
router.get('/wallets', UserController.getWallets);

router.post('/wallets', 
  requireEmailVerification,
  validateWalletCreation,
  validateWalletAddressMiddleware,
  UserController.addWallet
);

router.delete('/wallets/:id', 
  requireEmailVerification,
  validateUuidParam('id'),
  UserController.removeWallet
);

router.put('/wallets/:id/label', 
  requireEmailVerification,
  validateUuidParam('id'),
  UserController.updateWalletLabel
);

// Verificação de carteira (não requer autenticação completa)
router.get('/verify-wallet/:token', 
  validateUuidParam('token'),
  UserController.verifyWallet
);

// Gerenciamento de 2FA
router.post('/2fa/enable', 
  requireEmailVerification,
  UserController.enable2FA
);

router.post('/2fa/disable', 
  requireEmailVerification,
  UserController.disable2FA
);

module.exports = router;
