const express = require('express');
const router = express.Router();
const TransactionController = require('../controllers/transactionController');
const { 
  authenticateToken, 
  requireEmailVerification, 
  requireKycApproval 
} = require('../middleware/auth');
const { 
  validateTransactionCreation,
  validateUuidParam,
  validatePagination 
} = require('../middleware/validation');

// Middleware de autenticação para todas as rotas
router.use(authenticateToken);
router.use(requireEmailVerification);

// Obter cotação atual
router.get('/rate', TransactionController.getCurrentRate);

// Criar nova transação (requer KYC aprovado)
router.post('/', 
  requireKycApproval,
  validateTransactionCreation, 
  TransactionController.createTransaction
);

// Listar transações do usuário
router.get('/', 
  validatePagination,
  TransactionController.getTransactions
);

// Obter estatísticas de transações
router.get('/stats', TransactionController.getTransactionStats);

// Obter transação específica
router.get('/:id', 
  validateUuidParam('id'),
  TransactionController.getTransaction
);

module.exports = router;
