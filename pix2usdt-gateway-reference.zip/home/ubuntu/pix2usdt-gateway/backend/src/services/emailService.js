// Serviço de E-mail para PIX2USDT Gateway
// Este é um mock service - em produção, integrar com SendGrid, Mailgun, etc.

class EmailService {
  constructor() {
    this.isConfigured = false;
    this.init();
  }

  init() {
    // Em produção, configurar com as credenciais reais
    if (process.env.EMAIL_SERVICE && process.env.EMAIL_USER && process.env.EMAIL_PASSWORD) {
      this.isConfigured = true;
      console.log('Serviço de e-mail configurado');
    } else {
      console.log('Serviço de e-mail não configurado - usando mock');
    }
  }

  async sendVerificationEmail(email, token) {
    try {
      const verificationUrl = `${process.env.FRONTEND_URL || 'http://localhost:3000'}/verify-email/${token}`;
      
      const emailData = {
        to: email,
        subject: 'Verificação de E-mail - PIX2USDT Gateway',
        html: this.getVerificationEmailTemplate(verificationUrl)
      };

      if (this.isConfigured) {
        // Implementar envio real do e-mail
        return await this.sendEmail(emailData);
      } else {
        // Mock para desenvolvimento
        console.log('📧 E-mail de verificação (MOCK):');
        console.log(`Para: ${email}`);
        console.log(`URL de verificação: ${verificationUrl}`);
        return { success: true, messageId: 'mock-' + Date.now() };
      }
    } catch (error) {
      console.error('Erro ao enviar e-mail de verificação:', error);
      throw error;
    }
  }

  async sendWalletVerificationEmail(email, token, walletAddress, network) {
    try {
      const verificationUrl = `${process.env.FRONTEND_URL || 'http://localhost:3000'}/verify-wallet/${token}`;
      
      const emailData = {
        to: email,
        subject: 'Verificação de Carteira - PIX2USDT Gateway',
        html: this.getWalletVerificationEmailTemplate(verificationUrl, walletAddress, network)
      };

      if (this.isConfigured) {
        return await this.sendEmail(emailData);
      } else {
        console.log('📧 E-mail de verificação de carteira (MOCK):');
        console.log(`Para: ${email}`);
        console.log(`Carteira: ${walletAddress} (${network})`);
        console.log(`URL de verificação: ${verificationUrl}`);
        return { success: true, messageId: 'mock-' + Date.now() };
      }
    } catch (error) {
      console.error('Erro ao enviar e-mail de verificação de carteira:', error);
      throw error;
    }
  }

  async sendTransactionNotification(email, transactionData) {
    try {
      const emailData = {
        to: email,
        subject: `Atualização da Transação - ${transactionData.status}`,
        html: this.getTransactionNotificationTemplate(transactionData)
      };

      if (this.isConfigured) {
        return await this.sendEmail(emailData);
      } else {
        console.log('📧 Notificação de transação (MOCK):');
        console.log(`Para: ${email}`);
        console.log(`Transação: ${transactionData.id}`);
        console.log(`Status: ${transactionData.status}`);
        return { success: true, messageId: 'mock-' + Date.now() };
      }
    } catch (error) {
      console.error('Erro ao enviar notificação de transação:', error);
      throw error;
    }
  }

  async sendEmail(emailData) {
    // Implementação real do envio de e-mail
    // Exemplo com SendGrid:
    /*
    const sgMail = require('@sendgrid/mail');
    sgMail.setApiKey(process.env.SENDGRID_API_KEY);
    
    const msg = {
      to: emailData.to,
      from: process.env.FROM_EMAIL,
      subject: emailData.subject,
      html: emailData.html,
    };
    
    return await sgMail.send(msg);
    */
    
    throw new Error('Implementação real do e-mail não configurada');
  }

  getVerificationEmailTemplate(verificationUrl) {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Verificação de E-mail</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #2563eb; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background: #f9f9f9; }
          .button { display: inline-block; background: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
          .footer { padding: 20px; text-align: center; font-size: 12px; color: #666; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>PIX2USDT Gateway</h1>
          </div>
          <div class="content">
            <h2>Verificação de E-mail</h2>
            <p>Obrigado por se cadastrar no PIX2USDT Gateway!</p>
            <p>Para ativar sua conta, clique no botão abaixo:</p>
            <a href="${verificationUrl}" class="button">Verificar E-mail</a>
            <p>Ou copie e cole este link no seu navegador:</p>
            <p><a href="${verificationUrl}">${verificationUrl}</a></p>
            <p>Este link expira em 24 horas.</p>
          </div>
          <div class="footer">
            <p>PIX2USDT Gateway - Conversão instantânea de PIX para USDT</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  getWalletVerificationEmailTemplate(verificationUrl, walletAddress, network) {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Verificação de Carteira</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #2563eb; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background: #f9f9f9; }
          .button { display: inline-block; background: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
          .wallet-info { background: white; padding: 15px; border-radius: 5px; margin: 15px 0; }
          .footer { padding: 20px; text-align: center; font-size: 12px; color: #666; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>PIX2USDT Gateway</h1>
          </div>
          <div class="content">
            <h2>Verificação de Carteira</h2>
            <p>Você adicionou uma nova carteira à sua conta:</p>
            <div class="wallet-info">
              <strong>Endereço:</strong> ${walletAddress}<br>
              <strong>Rede:</strong> ${network}
            </div>
            <p>Para confirmar que esta carteira pertence a você, clique no botão abaixo:</p>
            <a href="${verificationUrl}" class="button">Verificar Carteira</a>
            <p>Ou copie e cole este link no seu navegador:</p>
            <p><a href="${verificationUrl}">${verificationUrl}</a></p>
            <p>Este link expira em 24 horas.</p>
          </div>
          <div class="footer">
            <p>PIX2USDT Gateway - Conversão instantânea de PIX para USDT</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  getTransactionNotificationTemplate(transactionData) {
    const statusMessages = {
      'pending': 'Aguardando pagamento PIX',
      'pix_confirmed': 'PIX confirmado, processando compra de USDT',
      'usdt_purchased': 'USDT comprado, preparando envio',
      'usdt_sent': 'USDT enviado para sua carteira',
      'completed': 'Transação concluída com sucesso',
      'failed': 'Transação falhou',
      'cancelled': 'Transação cancelada'
    };

    const statusMessage = statusMessages[transactionData.status] || 'Status atualizado';

    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Atualização de Transação</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #2563eb; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background: #f9f9f9; }
          .transaction-info { background: white; padding: 15px; border-radius: 5px; margin: 15px 0; }
          .status { padding: 10px; border-radius: 5px; margin: 15px 0; text-align: center; font-weight: bold; }
          .status.completed { background: #d4edda; color: #155724; }
          .status.failed { background: #f8d7da; color: #721c24; }
          .status.pending { background: #fff3cd; color: #856404; }
          .footer { padding: 20px; text-align: center; font-size: 12px; color: #666; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>PIX2USDT Gateway</h1>
          </div>
          <div class="content">
            <h2>Atualização de Transação</h2>
            <div class="status ${transactionData.status}">
              ${statusMessage}
            </div>
            <div class="transaction-info">
              <strong>ID da Transação:</strong> ${transactionData.id}<br>
              <strong>Valor PIX:</strong> R$ ${transactionData.pixAmount}<br>
              <strong>Valor USDT:</strong> ${transactionData.usdtAmount} USDT<br>
              ${transactionData.destinationAddress ? `<strong>Carteira de Destino:</strong> ${transactionData.destinationAddress}<br>` : ''}
              ${transactionData.blockchainTxHash ? `<strong>Hash da Transação:</strong> ${transactionData.blockchainTxHash}<br>` : ''}
            </div>
            <p>Você pode acompanhar o status da sua transação na sua conta.</p>
          </div>
          <div class="footer">
            <p>PIX2USDT Gateway - Conversão instantânea de PIX para USDT</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }
}

module.exports = new EmailService();
