const sqlite3 = require('sqlite3').verbose();
const path = require('path');

class DatabaseSQLite {
  constructor() {
    this.db = null;
    this.init();
  }

  init() {
    const dbPath = path.join(__dirname, '../../database/pix2usdt.db');
    
    this.db = new sqlite3.Database(dbPath, (err) => {
      if (err) {
        console.error('Erro ao conectar com SQLite:', err.message);
      } else {
        console.log('Conectado ao banco SQLite');
        this.createTables();
      }
    });
  }

  createTables() {
    const tables = [
      `CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        phone TEXT,
        pix_key TEXT,
        kyc_status TEXT DEFAULT 'pending',
        email_verified BOOLEAN DEFAULT FALSE,
        email_verification_token TEXT,
        two_factor_enabled BOOLEAN DEFAULT FALSE,
        two_factor_secret TEXT,
        is_active BOOLEAN DEFAULT TRUE,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      
      `CREATE TABLE IF NOT EXISTS wallets (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        wallet_address TEXT NOT NULL,
        network TEXT NOT NULL,
        label TEXT,
        is_verified BOOLEAN DEFAULT FALSE,
        verification_token TEXT,
        is_active BOOLEAN DEFAULT TRUE,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id),
        UNIQUE(wallet_address, network)
      )`,
      
      `CREATE TABLE IF NOT EXISTS transactions (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        status TEXT DEFAULT 'pending',
        pix_amount REAL NOT NULL,
        usdt_amount REAL NOT NULL,
        usdt_rate REAL NOT NULL,
        platform_fee REAL DEFAULT 0,
        exchange_fee REAL DEFAULT 0,
        network_fee REAL DEFAULT 0,
        pix_key TEXT,
        pix_qr_code TEXT,
        pix_transaction_id TEXT,
        pix_confirmed_at DATETIME,
        destination_wallet_id TEXT,
        destination_address TEXT,
        destination_network TEXT,
        blockchain_tx_hash TEXT,
        exchange_order_id TEXT,
        error_message TEXT,
        metadata TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id),
        FOREIGN KEY (destination_wallet_id) REFERENCES wallets (id)
      )`
    ];

    tables.forEach(sql => {
      this.db.run(sql, (err) => {
        if (err) {
          console.error('Erro ao criar tabela:', err.message);
        }
      });
    });
  }

  query(sql, params = []) {
    return new Promise((resolve, reject) => {
      this.db.all(sql, params, (err, rows) => {
        if (err) {
          reject(err);
        } else {
          resolve(rows);
        }
      });
    });
  }

  run(sql, params = []) {
    return new Promise((resolve, reject) => {
      this.db.run(sql, params, function(err) {
        if (err) {
          reject(err);
        } else {
          resolve({ id: this.lastID, changes: this.changes });
        }
      });
    });
  }

  get(sql, params = []) {
    return new Promise((resolve, reject) => {
      this.db.get(sql, params, (err, row) => {
        if (err) {
          reject(err);
        } else {
          resolve(row);
        }
      });
    });
  }

  close() {
    return new Promise((resolve, reject) => {
      this.db.close((err) => {
        if (err) {
          reject(err);
        } else {
          console.log('Conexão SQLite fechada');
          resolve();
        }
      });
    });
  }
}

module.exports = new DatabaseSQLite();
