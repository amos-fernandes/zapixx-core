const db = require("../config/database_sqlite");

module.exports = db;
