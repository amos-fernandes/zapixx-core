const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const db = require('../config/database_sqlite');

class User {
  static async create(userData) {
    const { email, password, firstName, lastName, phone, pixKey } = userData;
    
    // Hash da senha
    const saltRounds = 12;
    const passwordHash = await bcrypt.hash(password, saltRounds);
    
    // Gerar IDs
    const userId = uuidv4();
    const emailVerificationToken = uuidv4();
    
    const sql = `
      INSERT INTO users (
        id, email, password_hash, first_name, last_name, 
        phone, pix_key, email_verification_token
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;
    
    await db.run(sql, [
      userId, email, passwordHash, firstName, lastName,
      phone, pixKey, emailVerificationToken
    ]);
    
    const user = await this.findById(userId);
    
    return {
      user,
      emailVerificationToken
    };
  }

  static async findByEmail(email) {
    const sql = 'SELECT * FROM users WHERE email = ? AND is_active = TRUE';
    return await db.get(sql, [email]);
  }

  static async findById(id) {
    const sql = 'SELECT * FROM users WHERE id = ? AND is_active = TRUE';
    return await db.get(sql, [id]);
  }

  static async verifyPassword(password, hash) {
    return await bcrypt.compare(password, hash);
  }

  static async verifyEmail(token) {
    const sql = `
      UPDATE users 
      SET email_verified = TRUE, email_verification_token = NULL, updated_at = CURRENT_TIMESTAMP
      WHERE email_verification_token = ? AND is_active = TRUE
    `;
    
    const result = await db.run(sql, [token]);
    
    if (result.changes > 0) {
      const userSql = 'SELECT * FROM users WHERE email_verified = TRUE AND is_active = TRUE ORDER BY updated_at DESC LIMIT 1';
      return await db.get(userSql);
    }
    
    return null;
  }

  static async updatePixKey(userId, pixKey) {
    const sql = `
      UPDATE users 
      SET pix_key = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ? AND is_active = TRUE
    `;
    
    await db.run(sql, [pixKey, userId]);
    return await this.findById(userId);
  }

  static async enable2FA(userId, secret) {
    const sql = `
      UPDATE users 
      SET two_factor_enabled = TRUE, two_factor_secret = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ? AND is_active = TRUE
    `;
    
    await db.run(sql, [secret, userId]);
    return await this.findById(userId);
  }

  static async disable2FA(userId) {
    const sql = `
      UPDATE users 
      SET two_factor_enabled = FALSE, two_factor_secret = NULL, updated_at = CURRENT_TIMESTAMP
      WHERE id = ? AND is_active = TRUE
    `;
    
    await db.run(sql, [userId]);
    return await this.findById(userId);
  }
}

module.exports = User;
