const { v4: uuidv4 } = require("uuid");
const db = require("../config/database"); // Agora aponta para database_sqlite

class Wallet {
  static async create(walletData) {
    const { userId, walletAddress, network, label } = walletData;
    const walletId = uuidv4();
    const verificationToken = uuidv4();

    const sql = `
      INSERT INTO wallets (
        id, user_id, wallet_address, network, label, verification_token
      ) VALUES (?, ?, ?, ?, ?, ?)
    `;

    await db.run(sql, [
      walletId, userId, walletAddress, network, label, verificationToken
    ]);

    const wallet = await this.findById(walletId);

    return {
      wallet,
      verificationToken
    };
  }

  static async findById(id) {
    const sql = "SELECT * FROM wallets WHERE id = ? AND is_active = TRUE";
    return await db.get(sql, [id]);
  }

  static async findByAddressAndNetwork(walletAddress, network) {
    const sql = "SELECT * FROM wallets WHERE wallet_address = ? AND network = ? AND is_active = TRUE";
    return await db.get(sql, [walletAddress, network]);
  }

  static async findByUserId(userId) {
    const sql = "SELECT * FROM wallets WHERE user_id = ? AND is_active = TRUE ORDER BY created_at DESC";
    return await db.all(sql, [userId]);
  }

  static async verifyWallet(token) {
    const sql = `
      UPDATE wallets 
      SET is_verified = TRUE, verification_token = NULL, updated_at = CURRENT_TIMESTAMP
      WHERE verification_token = ? AND is_active = TRUE
    `;

    const result = await db.run(sql, [token]);

    if (result.changes > 0) {
      const walletSql = "SELECT * FROM wallets WHERE is_verified = TRUE AND is_active = TRUE ORDER BY updated_at DESC LIMIT 1";
      return await db.get(walletSql);
    }

    return null;
  }

  static async deactivate(id, userId) {
    const sql = `
      UPDATE wallets 
      SET is_active = FALSE, updated_at = CURRENT_TIMESTAMP
      WHERE id = ? AND user_id = ?
    `;
    const result = await db.run(sql, [id, userId]);
    return result.changes > 0;
  }

  static async updateLabel(id, userId, label) {
    const sql = `
      UPDATE wallets 
      SET label = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ? AND user_id = ? AND is_active = TRUE
      RETURNING *
    `;
    await db.run(sql, [label, id, userId]);
    return await this.findById(id);
  }
}

module.exports = Wallet;
