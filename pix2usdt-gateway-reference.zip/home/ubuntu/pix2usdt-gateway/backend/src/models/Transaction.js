const db = require("../config/database"); // Agora aponta para database_sqlite
const { v4: uuidv4 } = require("uuid");

class Transaction {
  static async create(transactionData) {
    const {
      userId,
      pixAmount,
      usdtAmount,
      usdtRate,
      pixKey,
      pixQrCode,
      destinationWalletId,
      destinationAddress,
      destinationNetwork,
      platformFee,
      exchangeFee,
      networkFee,
      metadata
    } = transactionData;

    const transactionId = uuidv4();

    const sql = `
      INSERT INTO transactions (
        id, user_id, pix_amount, usdt_amount, usdt_rate, pix_key, pix_qr_code,
        destination_wallet_id, destination_address, destination_network,
        platform_fee, exchange_fee, network_fee, metadata
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const values = [
      transactionId, userId, pixAmount, usdtAmount, usdtRate, pixKey, pixQrCode,
      destinationWalletId, destinationAddress, destinationNetwork,
      platformFee, exchangeFee, networkFee, JSON.stringify(metadata)
    ];

    await db.run(sql, values);
    return await this.findById(transactionId);
  }

  static async findById(id) {
    const sql = "SELECT * FROM transactions WHERE id = ?";
    return await db.get(sql, [id]);
  }

  static async findByUserId(userId, limit = 50, offset = 0) {
    const sql = `
      SELECT * FROM transactions 
      WHERE user_id = ? 
      ORDER BY created_at DESC 
      LIMIT ? OFFSET ?
    `;
    return await db.all(sql, [userId, limit, offset]);
  }

  static async updateStatus(id, status, additionalData = {}) {
    const setClause = ["status = ?", "updated_at = CURRENT_TIMESTAMP"];
    const values = [status];

    // Adicionar campos opcionais baseados no status
    if (additionalData.pixTransactionId) {
      setClause.push("pix_transaction_id = ?");
      values.push(additionalData.pixTransactionId);
    }

    if (additionalData.pixConfirmedAt) {
      setClause.push("pix_confirmed_at = ?");
      values.push(additionalData.pixConfirmedAt);
    }

    if (additionalData.exchangeOrderId) {
      setClause.push("exchange_order_id = ?");
      values.push(additionalData.exchangeOrderId);
    }

    if (additionalData.blockchainTxHash) {
      setClause.push("blockchain_tx_hash = ?");
      values.push(additionalData.blockchainTxHash);
    }

    if (additionalData.errorMessage) {
      setClause.push("error_message = ?");
      values.push(additionalData.errorMessage);
    }

    values.push(id); // O ID da transação é o último parâmetro para a cláusula WHERE

    const sql = `
      UPDATE transactions 
      SET ${setClause.join(", ")}
      WHERE id = ?
    `;

    await db.run(sql, values);
    return await this.findById(id);
  }

  static async findPendingPixTransactions() {
    const sql = `
      SELECT * FROM transactions 
      WHERE status = 'pending' 
      AND created_at > datetime('now', '-1 hour')
      ORDER BY created_at ASC
    `;
    return await db.all(sql);
  }

  static async findConfirmedPixTransactions() {
    const sql = `
      SELECT * FROM transactions 
      WHERE status = 'pix_confirmed' 
      ORDER BY pix_confirmed_at ASC
    `;
    return await db.all(sql);
  }

  static async getTransactionStats(userId, startDate, endDate) {
    const sql = `
      SELECT 
        COUNT(*) as total_transactions,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_transactions,
        SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed_transactions,
        SUM(CASE WHEN status = 'completed' THEN pix_amount ELSE 0 END) as total_pix_amount,
        SUM(CASE WHEN status = 'completed' THEN usdt_amount ELSE 0 END) as total_usdt_amount,
        AVG(CASE WHEN status = 'completed' THEN usdt_rate ELSE NULL END) as avg_rate
      FROM transactions 
      WHERE user_id = ? 
      AND created_at BETWEEN ? AND ?
    `;
    return await db.get(sql, [userId, startDate.toISOString(), endDate.toISOString()]);
  }
}

module.exports = Transaction;
