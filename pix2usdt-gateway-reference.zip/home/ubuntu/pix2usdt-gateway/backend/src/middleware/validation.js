const { body, param, query, validationResult } = require('express-validator');

// Middleware para verificar erros de validação
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      message: 'Dados inválidos',
      errors: errors.array()
    });
  }
  next();
};

// Validações para registro de usuário
const validateUserRegistration = [
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('E-mail inválido'),
  body('password')
    .isLength({ min: 8 })
    .withMessage('Senha deve ter pelo menos 8 caracteres')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/)
    .withMessage('Senha deve conter pelo menos: 1 letra minúscula, 1 maiúscula, 1 número e 1 caractere especial'),
  body('firstName')
    .trim()
    .isLength({ min: 2, max: 50 })
    .withMessage('Nome deve ter entre 2 e 50 caracteres'),
  body('lastName')
    .trim()
    .isLength({ min: 2, max: 50 })
    .withMessage('Sobrenome deve ter entre 2 e 50 caracteres'),
  body('phone')
    .optional()
    .isMobilePhone('pt-BR')
    .withMessage('Telefone inválido'),
  body('pixKey')
    .optional()
    .trim()
    .isLength({ min: 1, max: 255 })
    .withMessage('Chave PIX inválida'),
  handleValidationErrors
];

// Validações para login
const validateLogin = [
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('E-mail inválido'),
  body('password')
    .notEmpty()
    .withMessage('Senha é obrigatória'),
  handleValidationErrors
];

// Validações para criação de transação
const validateTransactionCreation = [
  body('pixAmount')
    .isFloat({ min: 1, max: 50000 })
    .withMessage('Valor PIX deve estar entre R$ 1,00 e R$ 50.000,00'),
  body('destinationWalletId')
    .optional()
    .isUUID()
    .withMessage('ID da carteira inválido'),
  body('destinationAddress')
    .optional()
    .trim()
    .isLength({ min: 26, max: 62 })
    .withMessage('Endereço de carteira inválido'),
  body('destinationNetwork')
    .optional()
    .isIn(['ERC20', 'TRC20', 'BEP20'])
    .withMessage('Rede deve ser ERC20, TRC20 ou BEP20'),
  handleValidationErrors
];

// Validações para carteira
const validateWalletCreation = [
  body('walletAddress')
    .trim()
    .isLength({ min: 26, max: 62 })
    .withMessage('Endereço de carteira inválido'),
  body('network')
    .isIn(['ERC20', 'TRC20', 'BEP20'])
    .withMessage('Rede deve ser ERC20, TRC20 ou BEP20'),
  body('label')
    .optional()
    .trim()
    .isLength({ max: 100 })
    .withMessage('Rótulo deve ter no máximo 100 caracteres'),
  handleValidationErrors
];

// Validações para atualização de PIX key
const validatePixKeyUpdate = [
  body('pixKey')
    .trim()
    .isLength({ min: 1, max: 255 })
    .withMessage('Chave PIX inválida'),
  handleValidationErrors
];

// Validações para parâmetros UUID
const validateUuidParam = (paramName) => [
  param(paramName)
    .isUUID()
    .withMessage(`${paramName} deve ser um UUID válido`),
  handleValidationErrors
];

// Validações para paginação
const validatePagination = [
  query('page')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Página deve ser um número inteiro positivo'),
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('Limite deve ser um número entre 1 e 100'),
  handleValidationErrors
];

// Validação de endereço de carteira baseado na rede
const validateWalletAddress = (address, network) => {
  const patterns = {
    ERC20: /^0x[a-fA-F0-9]{40}$/,
    TRC20: /^T[A-Za-z1-9]{33}$/,
    BEP20: /^0x[a-fA-F0-9]{40}$/
  };

  return patterns[network] && patterns[network].test(address);
};

// Middleware customizado para validar endereço de carteira
const validateWalletAddressMiddleware = (req, res, next) => {
  const { walletAddress, network } = req.body;
  
  if (walletAddress && network) {
    if (!validateWalletAddress(walletAddress, network)) {
      return res.status(400).json({
        message: 'Endereço de carteira inválido para a rede selecionada',
        errors: [{
          field: 'walletAddress',
          message: `Endereço inválido para a rede ${network}`
        }]
      });
    }
  }
  
  next();
};

module.exports = {
  validateUserRegistration,
  validateLogin,
  validateTransactionCreation,
  validateWalletCreation,
  validatePixKeyUpdate,
  validateUuidParam,
  validatePagination,
  validateWalletAddress,
  validateWalletAddressMiddleware,
  handleValidationErrors
};
