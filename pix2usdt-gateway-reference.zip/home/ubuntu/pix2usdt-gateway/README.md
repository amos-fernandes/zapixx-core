# PIX2USDT Gateway

Este projeto implementa um gateway para conversão instantânea de PIX (BRL) para USDT (Tether), conforme especificado no documento de requisitos. A solução é composta por um backend em Node.js (Express) e um frontend em React.

## Visão Geral

O PIX2USDT Gateway permite que usuários no Brasil convertam Reais (BRL) via PIX para USDT de forma rápida e segura. O sistema automatiza o processo de detecção de pagamentos PIX, compra de USDT em exchanges e envio para carteiras de destino (internas ou externas).

## Funcionalidades do MVP

- **Autenticação de Usuários:** Registro, Login, Verificação de E-mail.
- **Gestão de Perfil:** Atualização de chave PIX.
- **Gestão de Carteiras:** Adicionar, listar e remover carteiras USDT (ERC20, TRC20, BEP20).
- **Cotação em Tempo Real:** Obtenção da cotação USDT/BRL.
- **Criação de Transações:** Geração de QR Code/Chave PIX para pagamento.
- **Processamento de Transações:** Detecção de pagamento PIX, compra de USDT e envio para carteira de destino (funcionalidades mockadas para o MVP).
- **Segurança:** Implementação de middlewares de segurança (Helmet, Rate Limiting, CORS).
- **Validação de Entrada:** Validação de dados com `express-validator`.

## Estrutura do Projeto

```
pix2usdt-gateway/
├── backend/                  # Aplicação Node.js (Express)
│   ├── src/
│   │   ├── config/           # Configurações (DB, etc.)
│   │   ├── controllers/      # Lógica de negócio para rotas
│   │   ├── middleware/       # Middlewares (autenticação, validação)
│   │   ├── models/           # Modelos de dados (User, Transaction, Wallet)
│   │   ├── routes/           # Definição de rotas da API
│   │   └── services/         # Serviços externos (email, pix, exchange)
│   ├── database/             # Scripts SQL de inicialização
│   ├── .env                  # Variáveis de ambiente
│   ├── package.json
│   └── server.js             # Ponto de entrada do servidor
├── frontend/                 # Aplicação React
│   ├── pix2usdt-frontend/
│   │   ├── public/
│   │   ├── src/
│   │   │   ├── assets/
│   │   │   ├── components/   # Componentes reutilizáveis
│   │   │   ├── contexts/     # Contextos React (AuthContext)
│   │   │   ├── pages/        # Páginas da aplicação (Login, Register, Dashboard)
│   │   │   └── App.jsx       # Componente principal e roteamento
│   │   ├── .env              # Variáveis de ambiente do frontend
│   │   ├── index.html
│   │   ├── package.json
│   │   └── vite.config.js
├── test_system.js            # Script de testes automatizados
├── security_audit.js         # Script de auditoria de segurança
├── performance_optimizer.js  # Script de otimização de performance
├── security_report.txt       # Relatório de auditoria de segurança
├── performance_report.txt    # Relatório de análise de performance
└── README.md                 # Este arquivo
```

## Configuração e Execução (Desenvolvimento)

### Pré-requisitos

- Node.js (v18 ou superior)
- pnpm (gerenciador de pacotes)

### Backend

1.  **Navegue até o diretório do backend:**
    ```bash
    cd pix2usdt-gateway/backend
    ```

2.  **Instale as dependências:**
    ```bash
    pnpm install
    ```

3.  **Configure as variáveis de ambiente:**
    Crie um arquivo `.env` na raiz do diretório `backend` com o seguinte conteúdo (exemplo):
    ```env
    PORT=3001
    NODE_ENV=development
    JWT_SECRET=sua_chave_secreta_jwt_muito_segura_aqui_min_32_chars
    
    # Configurações do Banco de Dados (SQLite para desenvolvimento)
    # DB_HOST=localhost
    # DB_PORT=5432
    # DB_NAME=pix2usdt
    # DB_USER=user
    # DB_PASSWORD=password
    
    # Configurações de E-mail (Mock para desenvolvimento)
    EMAIL_SERVICE=mock
    FRONTEND_URL=http://localhost:5173
    
    # Configurações PIX (Mock para desenvolvimento)
    PIX_API_URL=mock
    PIX_API_KEY=mock
    
    # Configurações Exchange (Mock para desenvolvimento)
    EXCHANGE_API_URL=mock
    EXCHANGE_API_KEY=mock
    EXCHANGE_API_SECRET=mock
    
    # Rate Limiting
    RATE_LIMIT_WINDOW_MS=900000 # 15 minutos
    RATE_LIMIT_MAX_REQUESTS=100 # 100 requisições
    ```

4.  **Inicie o servidor:**
    ```bash
    pnpm start
    ```
    O servidor estará rodando em `http://localhost:3001`.

### Frontend

1.  **Navegue até o diretório do frontend:**
    ```bash
    cd pix2usdt-gateway/frontend/pix2usdt-frontend
    ```

2.  **Instale as dependências:**
    ```bash
    pnpm install
    ```

3.  **Configure as variáveis de ambiente:**
    Crie um arquivo `.env` na raiz do diretório `frontend/pix2usdt-frontend` com o seguinte conteúdo (exemplo):
    ```env
    VITE_API_BASE_URL=http://localhost:3001/api
    ```

4.  **Inicie a aplicação React:**
    ```bash
    pnpm dev
    ```
    A aplicação estará disponível em `http://localhost:5173`.

## Testes e Auditorias

Os seguintes scripts podem ser executados na raiz do projeto (`pix2usdt-gateway/`):

-   **Testes do Sistema:**
    ```bash
    node test_system.js
    ```
    Este script verifica a saúde do backend, endpoints de autenticação, cotação e a existência dos arquivos do frontend.

-   **Auditoria de Segurança:**
    ```bash
    node security_audit.js
    ```
    Gera um relatório detalhado sobre possíveis vulnerabilidades de segurança e recomendações.

-   **Análise de Performance:**
    ```bash
    node performance_optimizer.js
    ```
    Gera um relatório com métricas de performance estimadas e sugestões de otimização.

## Próximos Passos (Desenvolvimento)

Para evoluir o MVP, as seguintes áreas precisam de atenção:

-   **Integração Real:** Substituir os serviços mockados de PIX e Exchange por APIs reais (PagBrasil, Binance, etc.).
-   **KYC/AML:** Implementar um fluxo completo de verificação de identidade com um provedor de KYC/AML.
-   **Webhooks:** Configurar e processar webhooks para confirmação instantânea de pagamentos PIX e status de transações de exchange.
-   **Notificações:** Implementar notificações por e-mail e/ou push para o usuário sobre o status das transações.
-   **Gerenciamento de Erros:** Robustecer o tratamento de erros e retentativas para falhas de transação.
-   **Monitoramento:** Implementar ferramentas de monitoramento e logging para produção.
-   **Escalabilidade:** Otimizar o banco de dados e a arquitetura para alta carga.
-   **Frontend:** Desenvolver as páginas de Transações, Carteiras e Perfil completas.

---

**Desenvolvido por Manus AI**

