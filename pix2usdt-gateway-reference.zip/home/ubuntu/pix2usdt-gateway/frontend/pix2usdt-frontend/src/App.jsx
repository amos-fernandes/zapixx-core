import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Layout from './components/Layout';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import './App.css';

// Componente para rotas protegidas
const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();
  
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }
  
  return isAuthenticated ? children : <Navigate to="/login" />;
};

// Componente para rotas públicas (redireciona se já autenticado)
const PublicRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();
  
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }
  
  return !isAuthenticated ? children : <Navigate to="/dashboard" />;
};

function AppContent() {
  return (
    <Router>
      <Layout>
        <Routes>
          {/* Rotas públicas */}
          <Route path="/" element={<Home />} />
          <Route 
            path="/login" 
            element={
              <PublicRoute>
                <Login />
              </PublicRoute>
            } 
          />
          <Route 
            path="/register" 
            element={
              <PublicRoute>
                <Register />
              </PublicRoute>
            } 
          />
          
          {/* Rotas protegidas */}
          <Route 
            path="/dashboard" 
            element={
              <ProtectedRoute>
                <Dashboard />
              </ProtectedRoute>
            } 
          />
          
          {/* Placeholder para outras rotas protegidas */}
          <Route 
            path="/transactions" 
            element={
              <ProtectedRoute>
                <div className="text-center py-20">
                  <h1 className="text-2xl font-bold text-gray-900">Transações</h1>
                  <p className="text-gray-600 mt-2">Página em desenvolvimento</p>
                </div>
              </ProtectedRoute>
            } 
          />
          
          <Route 
            path="/wallets" 
            element={
              <ProtectedRoute>
                <div className="text-center py-20">
                  <h1 className="text-2xl font-bold text-gray-900">Carteiras</h1>
                  <p className="text-gray-600 mt-2">Página em desenvolvimento</p>
                </div>
              </ProtectedRoute>
            } 
          />
          
          <Route 
            path="/profile" 
            element={
              <ProtectedRoute>
                <div className="text-center py-20">
                  <h1 className="text-2xl font-bold text-gray-900">Perfil</h1>
                  <p className="text-gray-600 mt-2">Página em desenvolvimento</p>
                </div>
              </ProtectedRoute>
            } 
          />
          
          {/* Rota 404 */}
          <Route 
            path="*" 
            element={
              <div className="text-center py-20">
                <h1 className="text-4xl font-bold text-gray-900">404</h1>
                <p className="text-gray-600 mt-2">Página não encontrada</p>
                <a href="/" className="text-blue-600 hover:text-blue-500 mt-4 inline-block">
                  Voltar ao início
                </a>
              </div>
            } 
          />
        </Routes>
      </Layout>
    </Router>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
