import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  ArrowRightLeft, 
  Zap, 
  Shield, 
  Clock,
  CheckCircle,
  TrendingUp,
  Users,
  Globe,
  Smartphone,
  Lock
} from 'lucide-react';

const Home = () => {
  const features = [
    {
      icon: Zap,
      title: 'Conversão Instantânea',
      description: 'Converta PIX para USDT em segundos com nossa tecnologia automatizada'
    },
    {
      icon: Shield,
      title: 'Segurança Máxima',
      description: 'Verificação KYC/AML completa e criptografia de ponta a ponta'
    },
    {
      icon: Clock,
      title: 'Disponível 24/7',
      description: 'Funciona todos os dias, a qualquer hora, incluindo fins de semana'
    },
    {
      icon: TrendingUp,
      title: 'Melhores Taxas',
      description: 'Taxas competitivas e transparentes, sem surpresas'
    },
    {
      icon: Smartphone,
      title: 'Interface Intuitiva',
      description: 'Design moderno e fácil de usar, otimizado para mobile'
    },
    {
      icon: Globe,
      title: 'Múltiplas Redes',
      description: 'Suporte para ERC-20, TRC-20 e BEP-20'
    }
  ];

  const steps = [
    {
      number: '01',
      title: 'Criar Conta',
      description: 'Registre-se e complete a verificação de identidade'
    },
    {
      number: '02',
      title: 'Definir Valor',
      description: 'Digite o valor em reais que deseja converter'
    },
    {
      number: '03',
      title: 'Pagar com PIX',
      description: 'Escaneie o QR Code ou use a chave copia e cola'
    },
    {
      number: '04',
      title: 'Receber USDT',
      description: 'USDT é enviado automaticamente para sua carteira'
    }
  ];

  const stats = [
    { label: 'Transações Processadas', value: '10,000+' },
    { label: 'Usuários Ativos', value: '2,500+' },
    { label: 'Volume Total', value: 'R$ 50M+' },
    { label: 'Tempo Médio', value: '< 2 min' }
  ];

  return (
    <div className="space-y-20">
      {/* Hero Section */}
      <section className="text-center space-y-8 py-20">
        <div className="space-y-4">
          <Badge variant="outline" className="px-4 py-2">
            🚀 Conversão instantânea PIX → USDT
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 leading-tight">
            Converta PIX para USDT
            <br />
            <span className="text-blue-600">em segundos</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            A forma mais rápida e segura de converter seus reais para USDT. 
            Automatizado, confiável e disponível 24/7.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to="/register">
            <Button size="lg" className="px-8 py-3 text-lg">
              Começar Agora
              <ArrowRightLeft className="ml-2 w-5 h-5" />
            </Button>
          </Link>
          <Link to="/login">
            <Button variant="outline" size="lg" className="px-8 py-3 text-lg">
              Já tenho conta
            </Button>
          </Link>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 pt-16">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-3xl font-bold text-blue-600">{stat.value}</div>
              <div className="text-sm text-gray-600">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features Section */}
      <section className="space-y-12">
        <div className="text-center space-y-4">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
            Por que escolher o PIX2USDT?
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Desenvolvido especificamente para o mercado brasileiro, 
            oferecemos a melhor experiência de conversão fiat-crypto.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto">
                    <Icon className="w-6 h-6 text-blue-600" />
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </section>

      {/* How it Works */}
      <section className="space-y-12">
        <div className="text-center space-y-4">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
            Como funciona
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Processo simples e automatizado em apenas 4 passos
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="text-center space-y-4">
              <div className="w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto text-xl font-bold">
                {step.number}
              </div>
              <h3 className="text-xl font-semibold text-gray-900">{step.title}</h3>
              <p className="text-gray-600">{step.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Security Section */}
      <section className="bg-gray-50 rounded-2xl p-12 space-y-8">
        <div className="text-center space-y-4">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
            <Lock className="w-8 h-8 text-green-600" />
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
            Segurança em primeiro lugar
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Utilizamos os mais altos padrões de segurança da indústria para proteger seus dados e fundos
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center space-y-3">
            <CheckCircle className="w-8 h-8 text-green-600 mx-auto" />
            <h3 className="font-semibold">Verificação KYC/AML</h3>
            <p className="text-sm text-gray-600">
              Processo completo de verificação de identidade conforme regulamentações
            </p>
          </div>
          <div className="text-center space-y-3">
            <CheckCircle className="w-8 h-8 text-green-600 mx-auto" />
            <h3 className="font-semibold">Criptografia SSL</h3>
            <p className="text-sm text-gray-600">
              Todas as comunicações protegidas com criptografia de ponta a ponta
            </p>
          </div>
          <div className="text-center space-y-3">
            <CheckCircle className="w-8 h-8 text-green-600 mx-auto" />
            <h3 className="font-semibold">Auditoria Contínua</h3>
            <p className="text-sm text-gray-600">
              Monitoramento 24/7 e logs de auditoria para todas as transações
            </p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="text-center space-y-8 py-20">
        <div className="space-y-4">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
            Pronto para começar?
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Junte-se a milhares de usuários que já confiam no PIX2USDT para suas conversões
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to="/register">
            <Button size="lg" className="px-8 py-3 text-lg">
              Criar Conta Grátis
              <Users className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </div>

        <p className="text-sm text-gray-500">
          Sem taxas de cadastro • Verificação rápida • Suporte 24/7
        </p>
      </section>
    </div>
  );
};

export default Home;
