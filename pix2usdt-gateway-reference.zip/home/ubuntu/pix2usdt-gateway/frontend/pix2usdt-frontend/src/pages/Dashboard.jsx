import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { 
  ArrowRightLeft, 
  Loader2, 
  RefreshCw, 
  QrCode,
  Copy,
  CheckCircle,
  AlertCircle,
  TrendingUp,
  Wallet
} from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';

const conversionSchema = z.object({
  pixAmount: z.number().min(1, 'Valor mínimo é R$ 1,00').max(50000, 'Valor máximo é R$ 50.000,00'),
  destinationWalletId: z.string().optional(),
  destinationAddress: z.string().optional(),
  destinationNetwork: z.string().optional(),
});

const Dashboard = () => {
  const { user, api } = useAuth();
  const [loading, setLoading] = useState(false);
  const [rateLoading, setRateLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [rate, setRate] = useState(null);
  const [wallets, setWallets] = useState([]);
  const [showQrCode, setShowQrCode] = useState(false);
  const [transactionData, setTransactionData] = useState(null);
  const [copied, setCopied] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
    setValue,
    reset,
  } = useForm({
    resolver: zodResolver(conversionSchema),
    defaultValues: {
      pixAmount: 100,
    },
  });

  const pixAmount = watch('pixAmount');
  const destinationWalletId = watch('destinationWalletId');

  useEffect(() => {
    loadRate();
    loadWallets();
  }, []);

  useEffect(() => {
    if (pixAmount && rate) {
      // Atualizar cotação quando o valor mudar
      const debounce = setTimeout(() => {
        loadRate(pixAmount);
      }, 500);
      return () => clearTimeout(debounce);
    }
  }, [pixAmount]);

  const loadRate = async (amount = 100) => {
    setRateLoading(true);
    try {
      const response = await api.get(`/transactions/rate?amount=${amount}`);
      setRate(response.data);
    } catch (error) {
      console.error('Erro ao carregar cotação:', error);
    } finally {
      setRateLoading(false);
    }
  };

  const loadWallets = async () => {
    try {
      const response = await api.get('/users/wallets');
      setWallets(response.data.wallets.filter(w => w.isVerified));
    } catch (error) {
      console.error('Erro ao carregar carteiras:', error);
    }
  };

  const onSubmit = async (data) => {
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      const response = await api.post('/transactions', data);
      setTransactionData(response.data);
      setShowQrCode(true);
      setSuccess('Transação criada com sucesso! Efetue o pagamento PIX para continuar.');
      reset();
    } catch (error) {
      setError(error.response?.data?.message || 'Erro ao criar transação');
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const formatUSDT = (value) => {
    return `${parseFloat(value).toFixed(8)} USDT`;
  };

  if (!user?.emailVerified) {
    return (
      <div className="space-y-6">
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Você precisa verificar seu e-mail antes de poder fazer conversões. 
            Verifique sua caixa de entrada e clique no link de verificação.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  if (user?.kycStatus !== 'approved') {
    return (
      <div className="space-y-6">
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Você precisa completar a verificação de identidade (KYC) antes de poder fazer conversões.
            Entre em contato com o suporte para iniciar o processo.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Converter PIX para USDT</h1>
        <p className="text-gray-600">Converta seus reais para USDT de forma instantânea e segura</p>
      </div>

      {/* Rate Card */}
      {rate && (
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Cotação Atual</CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => loadRate(pixAmount)}
                disabled={rateLoading}
              >
                <RefreshCw className={`w-4 h-4 ${rateLoading ? 'animate-spin' : ''}`} />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <p className="text-sm text-gray-600">Taxa USDT/BRL</p>
                <p className="text-lg font-semibold">{formatCurrency(rate.rate)}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Taxa da plataforma</p>
                <p className="text-lg font-semibold">{(rate.platformFeeRate * 100).toFixed(1)}%</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Valor líquido</p>
                <p className="text-lg font-semibold">{formatCurrency(rate.netAmount)}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">USDT a receber</p>
                <p className="text-lg font-semibold text-green-600">{formatUSDT(rate.usdtAmount)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Conversion Form */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <ArrowRightLeft className="w-5 h-5" />
              <span>Nova Conversão</span>
            </CardTitle>
            <CardDescription>
              Digite o valor em reais que deseja converter para USDT
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              {success && (
                <Alert>
                  <CheckCircle className="h-4 w-4" />
                  <AlertDescription>{success}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="pixAmount">Valor em Reais (BRL)</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                    R$
                  </span>
                  <Input
                    id="pixAmount"
                    type="number"
                    step="0.01"
                    min="1"
                    max="50000"
                    placeholder="100.00"
                    className="pl-10"
                    {...register('pixAmount', { valueAsNumber: true })}
                  />
                </div>
                {errors.pixAmount && (
                  <p className="text-sm text-red-500">{errors.pixAmount.message}</p>
                )}
                <p className="text-xs text-gray-500">
                  Valor mínimo: R$ 1,00 | Valor máximo: R$ 50.000,00
                </p>
              </div>

              {rate && pixAmount && (
                <div className="bg-blue-50 p-4 rounded-lg space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Valor a pagar:</span>
                    <span className="font-semibold">{formatCurrency(pixAmount)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Taxa da plataforma:</span>
                    <span className="text-red-600">-{formatCurrency(rate.platformFee)}</span>
                  </div>
                  <div className="flex justify-between border-t pt-2">
                    <span className="font-semibold">USDT a receber:</span>
                    <span className="font-bold text-green-600">{formatUSDT(rate.usdtAmount)}</span>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Label>Destino do USDT</Label>
                <Select onValueChange={(value) => setValue('destinationWalletId', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione uma carteira ou deixe em branco para manter na plataforma" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Manter na plataforma</SelectItem>
                    {wallets.map((wallet) => (
                      <SelectItem key={wallet.id} value={wallet.id}>
                        <div className="flex items-center space-x-2">
                          <Badge variant="outline">{wallet.network}</Badge>
                          <span className="truncate">
                            {wallet.label || `${wallet.walletAddress.slice(0, 8)}...${wallet.walletAddress.slice(-6)}`}
                          </span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-gray-500">
                  Se não selecionar uma carteira, o USDT ficará disponível na sua conta da plataforma
                </p>
              </div>

              <Button
                type="submit"
                className="w-full"
                disabled={loading || !rate || !pixAmount}
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Criando transação...
                  </>
                ) : (
                  <>
                    <ArrowRightLeft className="mr-2 h-4 w-4" />
                    Converter para USDT
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* QR Code Display */}
        {showQrCode && transactionData && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <QrCode className="w-5 h-5" />
                <span>Pagamento PIX</span>
              </CardTitle>
              <CardDescription>
                Escaneie o QR Code ou copie a chave PIX para efetuar o pagamento
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <div className="bg-white p-4 rounded-lg border inline-block">
                  <img 
                    src={transactionData.paymentInfo.qrCode} 
                    alt="QR Code PIX"
                    className="w-48 h-48 mx-auto"
                  />
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <Label className="text-sm font-medium">Chave PIX (Copia e Cola)</Label>
                  <div className="flex items-center space-x-2 mt-1">
                    <Input
                      value={transactionData.paymentInfo.pixKey}
                      readOnly
                      className="font-mono text-sm"
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(transactionData.paymentInfo.pixKey)}
                    >
                      {copied ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>

                <div className="bg-yellow-50 p-3 rounded-lg">
                  <p className="text-sm text-yellow-800">
                    <strong>Importante:</strong> Efetue o pagamento de exatamente{' '}
                    <strong>{formatCurrency(transactionData.paymentInfo.amount)}</strong> para que a transação seja processada automaticamente.
                  </p>
                </div>

                <div className="text-xs text-gray-500 space-y-1">
                  <p>• O pagamento expira em 30 minutos</p>
                  <p>• A conversão será processada automaticamente após a confirmação do PIX</p>
                  <p>• Você receberá notificações por e-mail sobre o status da transação</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Quick Stats */}
        {!showQrCode && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <TrendingUp className="w-5 h-5" />
                <span>Estatísticas Rápidas</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Carteiras verificadas</span>
                  <Badge variant="outline">{wallets.length}</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Status KYC</span>
                  <Badge variant="default" className="bg-green-100 text-green-800">
                    Aprovado
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">E-mail verificado</span>
                  <Badge variant="default" className="bg-green-100 text-green-800">
                    Verificado
                  </Badge>
                </div>
                <Button variant="outline" className="w-full" asChild>
                  <a href="/wallets">
                    <Wallet className="w-4 h-4 mr-2" />
                    Gerenciar Carteiras
                  </a>
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
