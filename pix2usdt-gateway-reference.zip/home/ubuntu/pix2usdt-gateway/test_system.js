#!/usr/bin/env node

const axios = require('axios');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const API_BASE_URL = 'http://localhost:3001';
const FRONTEND_URL = 'http://localhost:5173';

class SystemTester {
  constructor() {
    this.backendProcess = null;
    this.frontendProcess = null;
    this.testResults = [];
  }

  log(message, type = 'info') {
    const timestamp = new Date().toISOString();
    const prefix = type === 'error' ? '❌' : type === 'success' ? '✅' : 'ℹ️';
    console.log(`${prefix} [${timestamp}] ${message}`);
  }

  async startBackend() {
    return new Promise((resolve, reject) => {
      this.log('Iniciando servidor backend...');
      
      this.backendProcess = spawn('npm', ['start'], {
        cwd: '/home/ubuntu/pix2usdt-gateway/backend',
        stdio: 'pipe'
      });

      this.backendProcess.stdout.on('data', (data) => {
        const output = data.toString();
        if (output.includes('Servidor rodando na porta')) {
          this.log('Backend iniciado com sucesso', 'success');
          resolve();
        }
      });

      this.backendProcess.stderr.on('data', (data) => {
        console.error('Backend stderr:', data.toString());
      });

      this.backendProcess.on('error', (error) => {
        this.log(`Erro ao iniciar backend: ${error.message}`, 'error');
        reject(error);
      });

      // Timeout de 30 segundos
      setTimeout(() => {
        reject(new Error('Timeout ao iniciar backend'));
      }, 30000);
    });
  }

  async testBackendHealth() {
    try {
      this.log('Testando saúde do backend...');
      const response = await axios.get(`${API_BASE_URL}/health`);
      
      if (response.status === 200 && response.data.status === 'healthy') {
        this.log('Backend health check passou', 'success');
        this.testResults.push({ test: 'Backend Health', status: 'PASS' });
        return true;
      } else {
        throw new Error('Health check retornou status inválido');
      }
    } catch (error) {
      this.log(`Backend health check falhou: ${error.message}`, 'error');
      this.testResults.push({ test: 'Backend Health', status: 'FAIL', error: error.message });
      return false;
    }
  }

  async testAuthEndpoints() {
    try {
      this.log('Testando endpoints de autenticação...');
      
      // Teste de registro com dados inválidos (deve falhar)
      try {
        await axios.post(`${API_BASE_URL}/api/auth/register`, {
          email: 'invalid-email',
          password: '123'
        });
        throw new Error('Registro com dados inválidos deveria ter falhado');
      } catch (error) {
        if (error.response && error.response.status === 400) {
          this.log('Validação de registro funcionando corretamente', 'success');
        } else {
          throw error;
        }
      }

      // Teste de login com credenciais inválidas (deve falhar)
      try {
        await axios.post(`${API_BASE_URL}/api/auth/login`, {
          email: 'test@test.com',
          password: 'wrongpassword'
        });
        throw new Error('Login com credenciais inválidas deveria ter falhado');
      } catch (error) {
        if (error.response && error.response.status === 401) {
          this.log('Validação de login funcionando corretamente', 'success');
        } else {
          throw error;
        }
      }

      this.testResults.push({ test: 'Auth Endpoints', status: 'PASS' });
      return true;
    } catch (error) {
      this.log(`Teste de autenticação falhou: ${error.message}`, 'error');
      this.testResults.push({ test: 'Auth Endpoints', status: 'FAIL', error: error.message });
      return false;
    }
  }

  async testRateEndpoint() {
    try {
      this.log('Testando endpoint de cotação...');
      const response = await axios.get(`${API_BASE_URL}/api/transactions/rate?amount=100`);
      
      if (response.status === 200 && response.data.rate && response.data.usdtAmount) {
        this.log('Endpoint de cotação funcionando', 'success');
        this.testResults.push({ test: 'Rate Endpoint', status: 'PASS' });
        return true;
      } else {
        throw new Error('Resposta de cotação inválida');
      }
    } catch (error) {
      this.log(`Teste de cotação falhou: ${error.message}`, 'error');
      this.testResults.push({ test: 'Rate Endpoint', status: 'FAIL', error: error.message });
      return false;
    }
  }

  async testDatabaseConnection() {
    try {
      this.log('Testando conexão com banco de dados...');
      
      // Verificar se os arquivos de modelo existem
      const modelsPath = '/home/ubuntu/pix2usdt-gateway/backend/src/models';
      const models = ['User.js', 'Transaction.js', 'Wallet.js'];
      
      for (const model of models) {
        const modelPath = path.join(modelsPath, model);
        if (!fs.existsSync(modelPath)) {
          throw new Error(`Modelo ${model} não encontrado`);
        }
      }

      this.log('Modelos de banco de dados encontrados', 'success');
      this.testResults.push({ test: 'Database Models', status: 'PASS' });
      return true;
    } catch (error) {
      this.log(`Teste de banco de dados falhou: ${error.message}`, 'error');
      this.testResults.push({ test: 'Database Models', status: 'FAIL', error: error.message });
      return false;
    }
  }

  async testFrontendBuild() {
    try {
      this.log('Testando build do frontend...');
      
      const frontendPath = '/home/ubuntu/pix2usdt-gateway/frontend/pix2usdt-frontend';
      
      // Verificar se os arquivos principais existem
      const requiredFiles = [
        'src/App.jsx',
        'src/contexts/AuthContext.jsx',
        'src/components/Layout.jsx',
        'src/pages/Home.jsx',
        'src/pages/Login.jsx',
        'src/pages/Register.jsx',
        'src/pages/Dashboard.jsx'
      ];

      for (const file of requiredFiles) {
        const filePath = path.join(frontendPath, file);
        if (!fs.existsSync(filePath)) {
          throw new Error(`Arquivo ${file} não encontrado`);
        }
      }

      this.log('Arquivos do frontend encontrados', 'success');
      this.testResults.push({ test: 'Frontend Files', status: 'PASS' });
      return true;
    } catch (error) {
      this.log(`Teste de frontend falhou: ${error.message}`, 'error');
      this.testResults.push({ test: 'Frontend Files', status: 'FAIL', error: error.message });
      return false;
    }
  }

  async testSecurityHeaders() {
    try {
      this.log('Testando headers de segurança...');
      const response = await axios.get(`${API_BASE_URL}/health`);
      
      const securityHeaders = [
        'x-content-type-options',
        'x-frame-options',
        'x-xss-protection'
      ];

      for (const header of securityHeaders) {
        if (!response.headers[header]) {
          this.log(`Header de segurança ${header} não encontrado`, 'error');
        }
      }

      this.log('Headers de segurança verificados', 'success');
      this.testResults.push({ test: 'Security Headers', status: 'PASS' });
      return true;
    } catch (error) {
      this.log(`Teste de segurança falhou: ${error.message}`, 'error');
      this.testResults.push({ test: 'Security Headers', status: 'FAIL', error: error.message });
      return false;
    }
  }

  async runAllTests() {
    try {
      this.log('=== Iniciando Testes do Sistema PIX2USDT Gateway ===');
      
      // Aguardar um pouco para o backend estar pronto
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      await this.testBackendHealth();
      await this.testAuthEndpoints();
      await this.testRateEndpoint();
      await this.testDatabaseConnection();
      await this.testFrontendBuild();
      await this.testSecurityHeaders();
      
      this.generateReport();
      
    } catch (error) {
      this.log(`Erro durante os testes: ${error.message}`, 'error');
    } finally {
      this.cleanup();
    }
  }

  generateReport() {
    this.log('=== Relatório de Testes ===');
    
    const passed = this.testResults.filter(r => r.status === 'PASS').length;
    const failed = this.testResults.filter(r => r.status === 'FAIL').length;
    
    this.testResults.forEach(result => {
      const status = result.status === 'PASS' ? '✅' : '❌';
      this.log(`${status} ${result.test}: ${result.status}`);
      if (result.error) {
        this.log(`   Erro: ${result.error}`);
      }
    });
    
    this.log(`\nResumo: ${passed} passou, ${failed} falhou`);
    
    if (failed === 0) {
      this.log('🎉 Todos os testes passaram!', 'success');
    } else {
      this.log(`⚠️  ${failed} teste(s) falharam`, 'error');
    }
  }

  cleanup() {
    this.log('Limpando processos...');
    
    if (this.backendProcess) {
      this.backendProcess.kill();
    }
    
    if (this.frontendProcess) {
      this.frontendProcess.kill();
    }
  }
}

// Executar testes se chamado diretamente
if (require.main === module) {
  const tester = new SystemTester();
  
  // Iniciar backend primeiro
  tester.startBackend()
    .then(() => tester.runAllTests())
    .catch(error => {
      console.error('Erro ao executar testes:', error);
      tester.cleanup();
      process.exit(1);
    });
}

module.exports = SystemTester;
