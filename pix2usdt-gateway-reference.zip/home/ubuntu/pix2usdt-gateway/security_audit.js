#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

class SecurityAuditor {
  constructor() {
    this.issues = [];
    this.warnings = [];
    this.recommendations = [];
  }

  log(message, type = 'info') {
    const timestamp = new Date().toISOString();
    const prefix = type === 'error' ? '🔴' : type === 'warning' ? '🟡' : type === 'success' ? '🟢' : 'ℹ️';
    console.log(`${prefix} [${timestamp}] ${message}`);
  }

  addIssue(severity, category, description, file = null) {
    this.issues.push({
      severity,
      category,
      description,
      file,
      timestamp: new Date().toISOString()
    });
  }

  addWarning(category, description, file = null) {
    this.warnings.push({
      category,
      description,
      file,
      timestamp: new Date().toISOString()
    });
  }

  addRecommendation(category, description) {
    this.recommendations.push({
      category,
      description,
      timestamp: new Date().toISOString()
    });
  }

  auditEnvironmentVariables() {
    this.log('Auditando variáveis de ambiente...');
    
    const envFile = '/home/ubuntu/pix2usdt-gateway/backend/.env';
    
    if (!fs.existsSync(envFile)) {
      this.addIssue('HIGH', 'Configuration', 'Arquivo .env não encontrado', envFile);
      return;
    }

    const envContent = fs.readFileSync(envFile, 'utf8');
    const lines = envContent.split('\n');

    // Verificar variáveis críticas
    const criticalVars = [
      'JWT_SECRET',
      'DATABASE_URL',
      'ENCRYPTION_KEY'
    ];

    const presentVars = [];
    lines.forEach(line => {
      if (line.includes('=')) {
        const [key] = line.split('=');
        presentVars.push(key.trim());
      }
    });

    criticalVars.forEach(varName => {
      if (!presentVars.includes(varName)) {
        this.addIssue('HIGH', 'Configuration', `Variável crítica ${varName} não definida`, envFile);
      }
    });

    // Verificar se JWT_SECRET é forte o suficiente
    const jwtSecretLine = lines.find(line => line.startsWith('JWT_SECRET='));
    if (jwtSecretLine) {
      const jwtSecret = jwtSecretLine.split('=')[1];
      if (!jwtSecret || jwtSecret.length < 32) {
        this.addIssue('HIGH', 'Authentication', 'JWT_SECRET muito fraco (deve ter pelo menos 32 caracteres)', envFile);
      }
    }

    this.log('Auditoria de variáveis de ambiente concluída');
  }

  auditPasswordSecurity() {
    this.log('Auditando segurança de senhas...');
    
    const userModelFile = '/home/ubuntu/pix2usdt-gateway/backend/src/models/User.js';
    
    if (fs.existsSync(userModelFile)) {
      const content = fs.readFileSync(userModelFile, 'utf8');
      
      // Verificar se está usando bcrypt
      if (!content.includes('bcrypt')) {
        this.addIssue('HIGH', 'Authentication', 'Hash de senha não está usando bcrypt', userModelFile);
      }
      
      // Verificar salt rounds
      const saltRoundsMatch = content.match(/saltRounds\s*=\s*(\d+)/);
      if (saltRoundsMatch) {
        const saltRounds = parseInt(saltRoundsMatch[1]);
        if (saltRounds < 12) {
          this.addWarning('Authentication', `Salt rounds muito baixo (${saltRounds}), recomendado: 12+`, userModelFile);
        }
      }
    }

    this.log('Auditoria de segurança de senhas concluída');
  }

  auditInputValidation() {
    this.log('Auditando validação de entrada...');
    
    const validationFile = '/home/ubuntu/pix2usdt-gateway/backend/src/middleware/validation.js';
    
    if (fs.existsSync(validationFile)) {
      const content = fs.readFileSync(validationFile, 'utf8');
      
      // Verificar se está usando express-validator
      if (!content.includes('express-validator')) {
        this.addIssue('MEDIUM', 'Input Validation', 'Não está usando express-validator para validação', validationFile);
      }
      
      // Verificar validações de e-mail
      if (!content.includes('isEmail')) {
        this.addWarning('Input Validation', 'Validação de e-mail pode estar ausente', validationFile);
      }
      
      // Verificar sanitização
      if (!content.includes('normalizeEmail') && !content.includes('trim')) {
        this.addWarning('Input Validation', 'Sanitização de entrada pode estar ausente', validationFile);
      }
    } else {
      this.addIssue('HIGH', 'Input Validation', 'Arquivo de validação não encontrado', validationFile);
    }

    this.log('Auditoria de validação de entrada concluída');
  }

  auditSQLInjection() {
    this.log('Auditando proteção contra SQL Injection...');
    
    const modelsDir = '/home/ubuntu/pix2usdt-gateway/backend/src/models';
    
    if (fs.existsSync(modelsDir)) {
      const modelFiles = fs.readdirSync(modelsDir).filter(file => file.endsWith('.js'));
      
      modelFiles.forEach(file => {
        const filePath = path.join(modelsDir, file);
        const content = fs.readFileSync(filePath, 'utf8');
        
        // Verificar se há concatenação de strings SQL
        if (content.includes('SELECT * FROM') && content.includes('+')) {
          this.addIssue('HIGH', 'SQL Injection', 'Possível concatenação de string SQL detectada', filePath);
        }
        
        // Verificar uso de prepared statements
        if (content.includes('query(') && !content.includes('$1')) {
          this.addWarning('SQL Injection', 'Considere usar prepared statements', filePath);
        }
      });
    }

    this.log('Auditoria de SQL Injection concluída');
  }

  auditCORS() {
    this.log('Auditando configuração CORS...');
    
    const serverFile = '/home/ubuntu/pix2usdt-gateway/backend/server.js';
    
    if (fs.existsSync(serverFile)) {
      const content = fs.readFileSync(serverFile, 'utf8');
      
      if (!content.includes('cors')) {
        this.addIssue('MEDIUM', 'CORS', 'CORS não configurado', serverFile);
      } else {
        // Verificar se CORS está muito permissivo
        if (content.includes("origin: '*'")) {
          this.addIssue('MEDIUM', 'CORS', 'CORS muito permissivo (origin: *)', serverFile);
        }
      }
    }

    this.log('Auditoria CORS concluída');
  }

  auditRateLimit() {
    this.log('Auditando rate limiting...');
    
    const serverFile = '/home/ubuntu/pix2usdt-gateway/backend/server.js';
    
    if (fs.existsSync(serverFile)) {
      const content = fs.readFileSync(serverFile, 'utf8');
      
      if (!content.includes('rate-limit') && !content.includes('rateLimit')) {
        this.addIssue('MEDIUM', 'Rate Limiting', 'Rate limiting não configurado', serverFile);
      }
    }

    this.log('Auditoria de rate limiting concluída');
  }

  auditSecurityHeaders() {
    this.log('Auditando headers de segurança...');
    
    const serverFile = '/home/ubuntu/pix2usdt-gateway/backend/server.js';
    
    if (fs.existsSync(serverFile)) {
      const content = fs.readFileSync(serverFile, 'utf8');
      
      if (!content.includes('helmet')) {
        this.addIssue('MEDIUM', 'Security Headers', 'Helmet não configurado para headers de segurança', serverFile);
      }
    }

    this.log('Auditoria de headers de segurança concluída');
  }

  auditFilePermissions() {
    this.log('Auditando permissões de arquivos...');
    
    const sensitiveFiles = [
      '/home/ubuntu/pix2usdt-gateway/backend/.env',
      '/home/ubuntu/pix2usdt-gateway/backend/src/config/database.js'
    ];

    sensitiveFiles.forEach(file => {
      if (fs.existsSync(file)) {
        const stats = fs.statSync(file);
        const mode = stats.mode & parseInt('777', 8);
        
        if (mode > parseInt('600', 8)) {
          this.addWarning('File Permissions', `Arquivo ${file} tem permissões muito abertas (${mode.toString(8)})`, file);
        }
      }
    });

    this.log('Auditoria de permissões de arquivos concluída');
  }

  auditDependencies() {
    this.log('Auditando dependências...');
    
    const packageFile = '/home/ubuntu/pix2usdt-gateway/backend/package.json';
    
    if (fs.existsSync(packageFile)) {
      const packageContent = JSON.parse(fs.readFileSync(packageFile, 'utf8'));
      
      // Verificar dependências de segurança recomendadas
      const securityDeps = ['helmet', 'express-rate-limit', 'express-validator'];
      const dependencies = { ...packageContent.dependencies, ...packageContent.devDependencies };
      
      securityDeps.forEach(dep => {
        if (!dependencies[dep]) {
          this.addWarning('Dependencies', `Dependência de segurança recomendada não encontrada: ${dep}`, packageFile);
        }
      });
    }

    this.log('Auditoria de dependências concluída');
  }

  generateSecurityRecommendations() {
    this.addRecommendation('Authentication', 'Implementar autenticação de dois fatores (2FA)');
    this.addRecommendation('Session Management', 'Implementar expiração automática de sessões');
    this.addRecommendation('Logging', 'Implementar logs de auditoria para todas as transações');
    this.addRecommendation('Encryption', 'Criptografar dados sensíveis no banco de dados');
    this.addRecommendation('API Security', 'Implementar assinatura de requests para APIs críticas');
    this.addRecommendation('Monitoring', 'Implementar monitoramento de segurança em tempo real');
    this.addRecommendation('Backup', 'Implementar backup seguro e criptografado dos dados');
    this.addRecommendation('Compliance', 'Revisar conformidade com LGPD e regulamentações financeiras');
  }

  runFullAudit() {
    this.log('=== Iniciando Auditoria de Segurança PIX2USDT Gateway ===');
    
    this.auditEnvironmentVariables();
    this.auditPasswordSecurity();
    this.auditInputValidation();
    this.auditSQLInjection();
    this.auditCORS();
    this.auditRateLimit();
    this.auditSecurityHeaders();
    this.auditFilePermissions();
    this.auditDependencies();
    this.generateSecurityRecommendations();
    
    this.generateReport();
  }

  generateReport() {
    this.log('=== Relatório de Auditoria de Segurança ===');
    
    // Contar por severidade
    const highIssues = this.issues.filter(i => i.severity === 'HIGH').length;
    const mediumIssues = this.issues.filter(i => i.severity === 'MEDIUM').length;
    const lowIssues = this.issues.filter(i => i.severity === 'LOW').length;
    
    this.log(`\n📊 Resumo:`);
    this.log(`   🔴 Problemas críticos: ${highIssues}`);
    this.log(`   🟡 Problemas médios: ${mediumIssues}`);
    this.log(`   🟠 Problemas baixos: ${lowIssues}`);
    this.log(`   ⚠️  Avisos: ${this.warnings.length}`);
    this.log(`   💡 Recomendações: ${this.recommendations.length}`);
    
    if (this.issues.length > 0) {
      this.log('\n🔴 Problemas Encontrados:');
      this.issues.forEach((issue, index) => {
        this.log(`${index + 1}. [${issue.severity}] ${issue.category}: ${issue.description}`);
        if (issue.file) {
          this.log(`   📁 Arquivo: ${issue.file}`);
        }
      });
    }
    
    if (this.warnings.length > 0) {
      this.log('\n⚠️  Avisos:');
      this.warnings.forEach((warning, index) => {
        this.log(`${index + 1}. ${warning.category}: ${warning.description}`);
        if (warning.file) {
          this.log(`   📁 Arquivo: ${warning.file}`);
        }
      });
    }
    
    if (this.recommendations.length > 0) {
      this.log('\n💡 Recomendações de Segurança:');
      this.recommendations.forEach((rec, index) => {
        this.log(`${index + 1}. ${rec.category}: ${rec.description}`);
      });
    }
    
    // Score de segurança
    const totalChecks = 20; // Número aproximado de verificações
    const issueWeight = { HIGH: 3, MEDIUM: 2, LOW: 1 };
    const totalDeductions = this.issues.reduce((sum, issue) => sum + issueWeight[issue.severity], 0);
    const securityScore = Math.max(0, Math.round(((totalChecks - totalDeductions) / totalChecks) * 100));
    
    this.log(`\n🛡️  Score de Segurança: ${securityScore}/100`);
    
    if (securityScore >= 80) {
      this.log('✅ Nível de segurança: BOM', 'success');
    } else if (securityScore >= 60) {
      this.log('⚠️  Nível de segurança: MÉDIO', 'warning');
    } else {
      this.log('🔴 Nível de segurança: BAIXO - Ação imediata necessária', 'error');
    }
  }
}

// Executar auditoria se chamado diretamente
if (require.main === module) {
  const auditor = new SecurityAuditor();
  auditor.runFullAudit();
}

module.exports = SecurityAuditor;
